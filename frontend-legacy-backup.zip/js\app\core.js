/* ================= core utilities ================= */
const $ = s => document.querySelector(s);
const esc = s => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
function fmt(s){
  return esc(s).replace(/`([^`]+)`/g, (m, c) => "<code>" + c + "</code>").replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
}
const plain = s => String(s).replace(/\*\*/g, "");
const KW = new Set("function const let var new this null true false undefined typeof instanceof export default extends implements interface public private protected static final void int double boolean long char throws throw catch package abstract super switch case SELECT FROM WHERE JOIN LEFT RIGHT INNER OUTER FULL ON GROUP BY ORDER HAVING LIMIT AS AND OR NOT NULL IS IN BETWEEN LIKE WITH OVER PARTITION DESC ASC INSERT UPDATE SET DELETE BEGIN COMMIT DISTINCT CREATE TABLE def class return if elif else for while in not and or is None True False import from as with try except finally raise yield lambda pass break continue async await global nonlocal del assert".split(" "));
const BI = new Set("print len range list dict set tuple int float str bool type isinstance enumerate zip sorted super open sum min max map filter round self".split(" "));
function hl(code){
  const re = /(#[^\n]*|\/\/[^\n]*|--\s[^\n]*)|("(?:[^"\\\n]|\\.)*"|'(?:[^'\\\n]|\\.)*')|\b([A-Za-z_][A-Za-z0-9_]*)\b|\b(\d+(?:\.\d+)?(?:e-?\d+)?)\b/g;
  let out = "", last = 0, m;
  while ((m = re.exec(code))) {
    out += esc(code.slice(last, m.index));
    if (m[1]) out += '<span class="c">' + esc(m[1]) + "</span>";
    else if (m[2]) out += '<span class="s">' + esc(m[2]) + "</span>";
    else if (m[3]) out += KW.has(m[3]) ? '<span class="k">' + m[3] + "</span>" : BI.has(m[3]) ? '<span class="b">' + m[3] + "</span>" : m[3];
    else out += '<span class="n">' + m[4] + "</span>";
    last = re.lastIndex;
  }
  return out + esc(code.slice(last));
}
function shuffle(a){ a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
const tday = () => Math.floor((Date.now() - new Date().getTimezoneOffset() * 60000) / 864e5);
const dayLabel = d => new Date(d * 864e5).toLocaleDateString(undefined, {timeZone:"UTC", month:"short", day:"numeric"});

const IC = {
  home:'<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  review:'<rect x="3" y="7" width="14" height="14" rx="2"/><path d="M7 3h12a2 2 0 0 1 2 2v12"/>',
  sheet:'<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/>',
  spark:'<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 15l.7 1.8 1.8.7-1.8.7L19 20l-.7-1.8-1.8-.7 1.8-.7z"/>',
  notes:'<path d="M5 4h10l4 4v12a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1z"/><path d="M14 4v5h5M8 13h8M8 17h5"/>',
  chart:'<path d="M4 20V11M10 20V5M16 20v-6M21 20H3"/>',
  gear:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M2 12h3M19 12h3M4.9 19.1L7 17M17 7l2.1-2.1"/>',
  menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',
  search:'<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
  out:'<path d="M15 4h4a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-4M10 17l5-5-5-5M15 12H3"/>',
  print:'<path d="M6 9V3h12v6M6 18H4a1 1 0 0 1-1-1v-6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v6a1 1 0 0 1-1 1h-2"/><rect x="6" y="14" width="12" height="7"/>',
  brain:'<path d="M9 4a3 3 0 0 0-3 3 3 3 0 0 0-2 5 3 3 0 0 0 2 5 3 3 0 0 0 6 1V5a3 3 0 0 0-3-1z"/><path d="M15 4a3 3 0 0 1 3 3 3 3 0 0 1 2 5 3 3 0 0 1-2 5 3 3 0 0 1-6 1"/>',
  fire:'<path d="M12 3c1 4 5 5 5 10a5 5 0 0 1-10 0c0-2.5 1.5-3.5 2-5 1 1.5 1.5 2 2.5 2C11 7 12 5 12 3z"/>',
  bolt:'<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
  trash:'<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  mic:'<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
  code:'<path d="M8 8l-4 4 4 4M16 8l4 4-4 4M14 5l-4 14"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  edit:'<path d="M4 20h4L19 9l-4-4L4 16z"/>',
  grid:'<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>'
};
const icon = n => `<span class="ic"><svg viewBox="0 0 24 24" aria-hidden="true">${IC[n]}</svg></span>`;

/* ================= skills & content ================= */
const FORMATS = [
  {id:"notes", name:"Notes", icon:"notes", desc:"Key points, a code example and interview traps"},
  {id:"cheat", name:"Cheat sheet", icon:"sheet", desc:"The whole topic on one dense card"},
  {id:"revision", name:"Revision", icon:"review", desc:"Spaced-repetition flashcards"},
  {id:"interview", name:"Interview", icon:"mic", desc:"Mock interview questions with model answers"},
  {id:"quiz", name:"Quiz", icon:"bolt", desc:"Multiple choice with combos and boss battles"},
  {id:"practical", name:"Practical", icon:"code", desc:"Timed code challenges in the arena"}
];
const FMT = Object.fromEntries(FORMATS.map(f => [f.id, f]));
const ALL_FMTS = FORMATS.map(f => f.id);
function autoPrac(t){
  const lines = t.code.split("\n"), out = [];
  const BAD = /\b(then|total|not|about|runs|works|changed|unchanged|pretend|no|remembered|matrix|product|element|solves|view|copy|rows|row|only|AND|per|overriding|wise|max|index|done|keys|case|happened|because)\b/i;
  lines.forEach((ln, i) => {
    const m = ln.match(/^(\s*(?:print|console\.log|System\.out\.println)\(.*\);?)\s+(?:#|\/\/)\s*(.+)$/);
    if (m && out.length < 2) {
      const ans = m[2].trim().split(/\s{2,}/)[0];
      if (ans.length <= 40 && !BAD.test(ans) && !/[A-Za-z]+ \d+,/.test(ans)) out.push({type:"predict", code:lines.slice(0, i).concat([m[1]]).join("\n"), answer:[ans], explain:"It prints `" + ans + "`."});
    }
  });
  const c = [];
  lines.forEach((ln, i) => { if (/^\s*(#|\/\/|--\s)/.test(ln)) return; const cp = ln.split(/\s(?:#|\/\/)\s/)[0]; const re = /\.([a-z_][a-z0-9_]{2,})\(/g; let m; while ((m = re.exec(cp))) c.push({i, tok:m[1], pos:m.index + 1}); });
  const used = new Set(), lns = new Set(); let n = 0;
  [0, Math.floor(c.length / 2), c.length - 1].forEach(k => {
    const x = c[k]; if (!x || n >= 2 || used.has(x.tok) || lns.has(x.i)) return;
    used.add(x.tok); lns.add(x.i); n++;
    const L = lines.slice(); L[x.i] = L[x.i].slice(0, x.pos) + "____" + L[x.i].slice(x.pos + x.tok.length);
    out.push({type:"blank", code:L.join("\n"), answer:[x.tok], explain:"The missing name is `" + x.tok + "`."});
  });
  return (t.prac || []).concat(out, PRAC_EXTRA[t.id] || []);
}
const CATS = [
  {id:"lang", name:"Programming languages"},
  {id:"web", name:"Web & full stack"},
  {id:"data", name:"Data analysis & visualization"},
  {id:"ai", name:"Machine learning & AI"},
  {id:"mine", name:"My courses"}
];
const BUILTIN = [
  {id:"python", cat:"lang", name:"Python", color:"var(--py)", icon:"🐍", blurb:"Core language, OOP, memory and concurrency", topics:PY},
  {id:"java", cat:"lang", name:"Java", color:"#D96A00", icon:"☕", blurb:"Syntax, OOP, collections, exceptions and threads", topics:C_JAVA},
  {id:"javascript", cat:"lang", name:"JavaScript", color:"#B89200", icon:"🟨", blurb:"Types, arrays, async and closures", topics:C_JS},
  {id:"sql", cat:"lang", name:"SQL", color:"#336791", icon:"🗄️", blurb:"Queries, joins, aggregates and window functions", topics:C_SQL},
  {id:"react", cat:"web", name:"React", color:"#149ECA", icon:"⚛️", blurb:"Components, hooks, patterns and performance", topics:C_REACT},
  {id:"tailwind", cat:"web", name:"Tailwind CSS", color:"#0891B2", icon:"🎨", blurb:"Utilities, layout, responsive design and config", topics:C_TW},
  {id:"javafs", cat:"web", name:"Java Full Stack", color:"#5B9A2E", icon:"🧱", blurb:"Spring Boot, REST, JPA, security and deployment", topics:C_JFS},
  {id:"pyfs", cat:"web", name:"Python Full Stack", color:"#00897B", icon:"🧩", blurb:"FastAPI, Django, auth and deployment", topics:C_PFS},
  {id:"numpy", cat:"data", name:"NumPy", color:"var(--np)", icon:"🔢", blurb:"Arrays, views, broadcasting and linear algebra", topics:NP},
  {id:"pandas", cat:"data", name:"Pandas", color:"var(--pd)", icon:"🐼", blurb:"Selection, cleaning, grouping and speed", topics:PD},
  {id:"matplotlib", cat:"data", name:"Matplotlib", color:"#11557C", icon:"📈", blurb:"Figures, chart types, layouts and ML visuals", topics:C_MPL},
  {id:"seaborn", cat:"data", name:"Seaborn", color:"#7A5195", icon:"📊", blurb:"Statistical plots, heatmaps and EDA", topics:C_SNS},
  {id:"sklearn", cat:"ai", name:"scikit-learn", color:"#E08A00", icon:"🧪", blurb:"Estimators, pipelines, models and tuning", topics:C_SK},
  {id:"ml", cat:"ai", name:"Machine Learning", color:"#2E7D32", icon:"🤖", blurb:"Fundamentals, regression, trees and production", topics:C_ML},
  {id:"dl", cat:"ai", name:"Deep Learning", color:"#7B1FA2", icon:"🧠", blurb:"Networks, training, regularization and architectures", topics:C_DL},
  {id:"pytorch", cat:"ai", name:"PyTorch", color:"var(--pt)", icon:"🔥", blurb:"Tensors, autograd and training loops", topics:PT},
  {id:"nlp", cat:"ai", name:"NLP", color:"#C2185B", icon:"💬", blurb:"Preprocessing, vectors, tasks and modern models", topics:C_NLP},
  {id:"transformers", cat:"ai", name:"Transformers", color:"#00838F", icon:"🔁", blurb:"Attention, blocks, model families and fine-tuning", topics:C_TF},
  {id:"llm", cat:"ai", name:"LLMs", color:"#3949AB", icon:"🗣️", blurb:"How LLMs work, prompting, apps and safety", topics:C_LLM},
  {id:"rag", cat:"ai", name:"RAG", color:"#E65100", icon:"🔎", blurb:"Retrieval, indexing, reranking and evaluation", topics:C_RAG}
];
const LVL = {B:"Basic", I:"Intermediate", A:"Advanced"};
BUILTIN.forEach(w => { w.formats = ALL_FMTS; const n = w.topics.length; w.topics.forEach((t, i) => {
  if (!t.lvl) t.lvl = i < n * 0.34 ? "B" : i < n * 0.75 ? "I" : "A";
  t.iq = t.cards.map(c => [c[0], c[1]]).concat(t.traps.map(x => ["What’s a common mistake with " + t.t.toLowerCase() + "?", x]));
  t.prac = autoPrac(t);
}); });
let WORLDS = [], ALL = [], BYID = {};
const emptyTopic = (id, t) => ({id, t, hook:"", sum:"", pts:[], code:"", traps:[], cards:[], quiz:[], iq:[], prac:[]});
function reindex(){
  const custom = LIB.skills.map(sk => ({id:sk.id, cat:"mine", name:sk.name, color:sk.color, icon:sk.icon, blurb:sk.goal || (sk.level ? sk.level + " level" : "Your own skill"), custom:true, skill:sk, formats:sk.formats,
    topics:sk.topics.map(st => { const c = TC[st.id]; return Object.assign(emptyTopic(st.id, st.t), c || {}, {id:st.id, t:(c && c.t) || st.t, planned:!c, lvl:(c && c.lvl) || "B"}); })}));
  WORLDS = BUILTIN.concat(custom);
  ALL = []; BYID = {};
  WORLDS.forEach(w => w.topics.forEach((t, i) => { t.world = w; t.idx = i; ALL.push(t); BYID[t.id] = t; }));
}
function topicFormats(t){
  const has = {notes:t.pts.length > 0, cheat:t.pts.length > 0, revision:t.cards.length > 0, interview:t.iq.length > 0, quiz:t.quiz.length > 0, practical:t.prac.length > 0};
  return t.world.formats.filter(f => has[f]);
}
const skillColors = ["#0E8580", "#5B45D6", "#C94A22", "#2F7DD1", "#B0367A", "#3F8F3A", "#9A6B00", "#475569"];
const skillIcons = ["🧠", "🗄️", "☁️", "⚛️", "🐳", "📊", "🤖", "🔐", "🧪", "📈", "🌐", "🛠️"];

/* ================= state & persistence ================= */
const KEY = "recall-v2", LKEY = "recall-lib-v1", TKEY = "recall-tc-v1";
const DEF_PREFS = {theme:"system", accent:"lagoon", size:"m", motion:true, goal:20, newLimit:10};
function freshState(){ return {v:2, xp:0, streak:0, best:0, last:null, cards:{}, topics:{}, badges:[], reviews:0, bosses:{}, flawless:false, lastTopic:null, lastRoute:null, days:{}, newDay:{d:0, n:0}, prefs:Object.assign({}, DEF_PREFS), focus:["python", "numpy", "pandas", "pytorch"], signedIn:false, onboarded:false, prevLast:null, arena:{best:0, played:0}, nailed:0, updatedAt:0}; }
function normalize(o){
  const s = Object.assign(freshState(), o || {});
  s.prefs = Object.assign({}, DEF_PREFS, s.prefs || {});
  s.arena = Object.assign({best:0, played:0}, s.arena || {});
  return s;
}
let S = freshState(), LIB = {skills:[], updatedAt:0}, TC = {};
reindex();

/* ================= accounts & sync through the Recall backend (FastAPI) ================= */
const API_URL = ((window.RECALL_CONFIG && window.RECALL_CONFIG.API_URL) || "http://localhost:8000").replace(/\/$/, "");
const TOKEN_KEY = "recall-token", ME_KEY = "recall-me";
const lsGet = (k, d) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } };
const ME = {id:null, name:"", email:""};
let TOKEN = localStorage.getItem(TOKEN_KEY) || "";
const cacheKey = () => "recall-cache:" + ME.id;

class ApiError extends Error { constructor(msg, status){ super(msg); this.status = status; } }
async function api(path, opts){
  opts = opts || {};
  const headers = {"Content-Type":"application/json"};
  if (TOKEN) headers.Authorization = "Bearer " + TOKEN;
  let res;
  try {
    res = await fetch(API_URL + path, {method:opts.method || "GET", headers, body:opts.body ? JSON.stringify(opts.body) : undefined, keepalive:!!opts.keepalive});
  } catch (e) { throw new ApiError("Can’t reach the Recall server. Check that the backend is running.", 0); }
  let data = null;
  try { data = await res.json(); } catch (e) {}
  if (!res.ok) {
    const d = data && data.detail;
    const msg = typeof d === "string" ? d : Array.isArray(d) ? d.map(x => x.msg).join(", ") : "Request failed (" + res.status + ")";
    throw new ApiError(msg, res.status);
  }
  return data;
}

function applyUserData(user, data){
  ME.id = user.id; ME.name = user.name; ME.email = user.email;
  lsSet(ME_KEY, user);
  S = normalize((data && data.progress) || {});
  LIB = Object.assign({skills:[], updatedAt:0}, (data && data.skills) || {});
  TC = (data && data.topics) || {};
  reindex();
  lsSet(cacheKey(), {progress:S, skills:LIB, topics:TC});
}
async function createAccount(name, email, pw){
  const r = await api("/api/auth/register", {method:"POST", body:{name, email, password:pw}});
  TOKEN = r.token; localStorage.setItem(TOKEN_KEY, TOKEN);
  applyUserData(r.user, null);
  await pushNow();
  return r.user;
}
async function signIn(email, pw){
  const r = await api("/api/auth/login", {method:"POST", body:{email, password:pw}});
  TOKEN = r.token; localStorage.setItem(TOKEN_KEY, TOKEN);
  const data = await api("/api/data");
  applyUserData(r.user, data);
  return r.user;
}
async function restoreSession(){
  if (!TOKEN) return false;
  try {
    const user = await api("/api/auth/me");
    const data = await api("/api/data");
    applyUserData(user, data);
    syncState = "saved";
    return true;
  } catch (e) {
    if (e.status === 401) { TOKEN = ""; localStorage.removeItem(TOKEN_KEY); return false; }
    const user = lsGet(ME_KEY, null);
    const cache = user && lsGet("recall-cache:" + user.id, null);
    if (user && cache) { applyUserData(user, cache); syncState = "offline"; return true; }
    return false;
  }
}
function signOutLocal(){
  flushSave();
  TOKEN = ""; localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(ME_KEY);
  authTab = "signin"; authErr = "";
  ME.id = null; ME.name = ""; ME.email = "";
  S = freshState(); LIB = {skills:[], updatedAt:0}; TC = {}; reindex();
}
async function updateAccount(patch){
  const user = await api("/api/auth/me", {method:"PATCH", body:patch});
  ME.name = user.name; lsSet(ME_KEY, user);
  return user;
}
async function changePassword(current, next){ await api("/api/auth/change-password", {method:"POST", body:{current_password:current, new_password:next}}); }
async function deleteAccount(){ await api("/api/auth/me", {method:"DELETE"}); }
function ensureQuickSkill(){
  let sk = LIB.skills.find(x => x.id === "notes");
  if (!sk) { sk = {id:"notes", name:"Quick notes", icon:"✨", color:"var(--acc)", formats:ALL_FMTS.slice(), goal:"One-off notes", level:"", topics:[], created:tday()}; LIB.skills.unshift(sk); }
  return sk;
}

/* saving: cached in the browser at once, pushed to the server shortly after */
let syncState = "saved", saveTimer = null;
function payload(){ return {progress:S, skills:LIB, topics:TC}; }
async function pushNow(keepalive){
  clearTimeout(saveTimer);
  if (!ME.id || !TOKEN) return;
  lsSet(cacheKey(), payload());
  syncState = "saving"; paintSync();
  try { await api("/api/data", {method:"PUT", body:payload(), keepalive}); syncState = "saved"; }
  catch (e) { syncState = e.status === 0 ? "offline" : "error"; }
  paintSync();
}
function flushSave(){ if (ME.id) pushNow(true); }
function queueSave(){
  if (!ME.id) return;
  lsSet(cacheKey(), payload());
  syncState = "saving"; paintSync();
  clearTimeout(saveTimer); saveTimer = setTimeout(() => pushNow(false), 1200);
}
function localSave(){ queueSave(); }
function save(){ S.updatedAt = Date.now(); queueSave(); }
function saveLib(){ LIB.updatedAt = Date.now(); queueSave(); }
function saveTopic(id){ queueSave(); }
function dropTopic(id){ delete TC[id]; queueSave(); }
function schedule(){ queueSave(); }
function flush(){ flushSave(); }
window.addEventListener("pagehide", flushSave);
document.addEventListener("visibilitychange", () => { if (document.visibilityState === "hidden") flushSave(); });
window.addEventListener("online", () => { if (syncState === "offline") pushNow(false); });
function backupAge(){ return S.lastBackup ? Math.floor((Date.now() - S.lastBackup) / 864e5) : null; }
function paintSync(){
  const el = document.getElementById("sync"); if (!el) return;
  el.textContent = syncState === "saving" ? "Saving…" : syncState === "offline" ? "Offline, will sync later" : syncState === "error" ? "Sync failed, retrying" : "All changes saved";
  el.dataset.state = syncState === "saved" ? "synced" : syncState === "saving" ? "syncing" : "error";
}

/* backups: move data between devices and keep it safe */
function exportBackup(){
  flushSave();
  const data = {app:"recall", version:3, exported:new Date().toISOString(), account:{name:ME.name, email:ME.email}, progress:S, skills:LIB, topics:TC};
  const blob = new Blob([JSON.stringify(data)], {type:"application/json"});
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "recall-backup-" + (ME.name || "me").toLowerCase().replace(/[^a-z0-9]+/g, "-") + "-" + new Date().toISOString().slice(0, 10) + ".json";
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  S.lastBackup = Date.now(); save();
  toast("Backup downloaded");
}
function importBackup(file, done){
  const r = new FileReader();
  r.onload = () => {
    try {
      const d = JSON.parse(r.result);
      if (d.app !== "recall" || !d.progress) throw 0;
      const keepPrefs = S.prefs;
      S = normalize(d.progress); S.prefs = Object.assign({}, keepPrefs, d.progress.prefs || {});
      S.onboarded = true;
      LIB = Object.assign({skills:[]}, d.skills || {}); TC = d.topics || {};
      reindex(); pushNow(false); done(true);
    } catch (e) { done(false); }
  };
  r.readAsText(file);
}

/* No AI connector: all study content ships with the app */
const sampleFn = null, sampleChecked = true;

/* ================= learning model ================= */
const IV = [0, 1, 3, 7, 16, 35, 75, 150], MAXBOX = 7;
const cardKey = (t, i) => t.id + "#" + i;
function cardR(st){
  if (!st) return null;
  const el = Math.max(0, tday() - (st.last == null ? tday() : st.last));
  return Math.pow(0.9, el / Math.max(1, IV[st.box] || 1));
}
function topicStats(t){
  let seen = 0, boxSum = 0, rSum = 0;
  t.cards.forEach((c, i) => { const st = S.cards[cardKey(t, i)]; if (st) { seen++; boxSum += st.box; rSum += cardR(st); } });
  const rec = S.topics[t.id] || {};
  if (t.planned) return {seen:0, avgBox:0, ret:null, mastery:0, status:"planned", learned:false};
  const avgBox = t.cards.length ? boxSum / t.cards.length : 0;
  const ret = seen ? rSum / seen : null;
  let mastery = (rec.learned ? 25 : 0) + (rec.quiz || 0) * 0.35 + (t.cards.length ? boxSum / (t.cards.length * MAXBOX) * 40 : 0);
  let status = "new";
  if (seen && ret < 0.8) status = "fading";
  else if (rec.learned || seen) status = avgBox >= 3 ? "strong" : "learning";
  return {seen, avgBox, ret, mastery:Math.round(mastery), status, learned:!!rec.learned};
}
const STATUS = {new:"New", learning:"Learning", strong:"Strong", fading:"Fading", planned:"Not generated"};
const pill = s => `<span class="pill ${s}">${STATUS[s]}</span>`;
const meter = (avg, color) => `<span class="meter" style="--wc:${color}" title="Memory strength ${avg.toFixed(1)} of ${MAXBOX}">${Array.from({length:MAXBOX}, (_, i) => `<i class="${i < Math.round(avg) ? "on" : ""}"></i>`).join("")}</span>`;
function worldStats(w){
  if (!w.topics.length) return {mastery:0, ret:null, learned:0};
  let m = 0, rs = 0, rn = 0, l = 0;
  w.topics.forEach(t => { const s = topicStats(t); m += s.mastery; if (s.ret != null) { rs += s.ret; rn++; } if (s.learned) l++; });
  return {mastery:Math.round(m / w.topics.length), ret:rn ? rs / rn : null, learned:l};
}
const learnedCount = () => ALL.filter(t => S.topics[t.id] && S.topics[t.id].learned).length;
const cardItem = (t, i) => ({id:cardKey(t, i), q:t.cards[i][0], a:t.cards[i][1], topic:t.t, color:t.world.color});
function newLeftToday(){ const d = tday(); return Math.max(0, S.prefs.newLimit - (S.newDay.d === d ? S.newDay.n : 0)); }
function reviewQueue(mode){
  const d = tday(), due = [], fresh = [];
  ALL.forEach(t => t.cards.forEach((c, i) => {
    const st = S.cards[cardKey(t, i)];
    if (st) { if (st.due <= d) due.push({r:cardR(st), due:st.due, item:cardItem(t, i)}); }
    else if (S.topics[t.id] && S.topics[t.id].learned) fresh.push(cardItem(t, i));
  }));
  if (mode === "catchup") { due.sort((a, b) => a.r - b.r); return due.slice(0, Math.max(10, S.prefs.goal)).map(x => x.item); }
  due.sort((a, b) => a.due - b.due);
  return due.map(x => x.item).concat(fresh.slice(0, newLeftToday()));
}
const reviewedToday = () => S.days[tday()] || 0;

/* ================= XP, levels, badges ================= */
const level = xp => Math.floor(Math.sqrt(xp / 40)) + 1;
const lvlStart = l => (l - 1) * (l - 1) * 40, lvlEnd = l => l * l * 40;
const RANKS = ["Novice", "Apprentice", "Coder", "Debugger", "Tensor tamer", "Gradient surfer", "Model whisperer", "AI architect"];
const rank = l => RANKS[Math.min(Math.floor((l - 1) / 2), RANKS.length - 1)];
const currentStreak = () => (S.last === tday() || S.last === tday() - 1) ? S.streak : 0;
const BADGES = [
  {id:"first", icon:"📘", name:"First page", how:"Learn your first topic", test:() => learnedCount() >= 1},
  {id:"tour", icon:"🧭", name:"World tour", how:"Learn a topic in every library", test:() => BUILTIN.every(w => w.topics.some(t => S.topics[t.id] && S.topics[t.id].learned))},
  {id:"book", icon:"📚", name:"Bookworm", how:"Learn 15 topics", test:() => learnedCount() >= 15},
  {id:"author", icon:"✍️", name:"Note taker", how:"Generate your first notes", test:() => Object.keys(TC).length > 0},
  {id:"skill", icon:"🌱", name:"New skill", how:"Add a skill of your own", test:() => LIB.skills.some(x => x.id !== "notes")},
  {id:"arena", icon:"🏟️", name:"Arena regular", how:"Finish 5 practical runs", test:() => S.arena.played >= 5},
  {id:"interview", icon:"🎤", name:"Interview ready", how:"Nail 25 mock interview answers", test:() => (S.nailed || 0) >= 25},
  {id:"shark", icon:"🃏", name:"Card shark", how:"Review 50 cards", test:() => S.reviews >= 50},
  {id:"palace", icon:"🏛️", name:"Memory palace", how:"Review 300 cards", test:() => S.reviews >= 300},
  {id:"fire", icon:"🔥", name:"On fire", how:"Keep a 3-day streak", test:() => currentStreak() >= 3},
  {id:"week", icon:"📅", name:"Week warrior", how:"Keep a 7-day streak", test:() => currentStreak() >= 7},
  {id:"flawless", icon:"💎", name:"Flawless", how:"Score 100% on a topic quiz", test:() => S.flawless},
  {id:"boss", icon:"⚔️", name:"Boss slayer", how:"Win a boss battle", test:() => Object.keys(S.bosses).length > 0},
  {id:"long", icon:"🗓️", name:"Long-term memory", how:"Get a card to the 75-day box", test:() => Object.values(S.cards).some(c => c.box >= 6)},
  {id:"master", icon:"👑", name:"Grandmaster", how:"80% mastery in all four libraries", test:() => BUILTIN.every(w => worldStats(w).mastery >= 80)}
];
function toast(msg, gold){
  const t = document.createElement("div");
  t.className = "toast" + (gold ? " gold" : "");
  t.textContent = msg;
  $("#toasts").appendChild(t);
  setTimeout(() => t.remove(), gold ? 3200 : 2000);
}
function touchStreak(){
  const d = tday();
  if (S.last === d) return;
  S.prevLast = S.last;
  S.streak = (S.last === d - 1) ? S.streak + 1 : 1;
  S.best = Math.max(S.best || 0, S.streak);
  S.last = d;
}
function checkBadges(){
  BADGES.forEach(b => { if (!S.badges.includes(b.id) && b.test()) { S.badges.push(b.id); toast("Badge unlocked: " + b.name, true); save(); } });
}
function gainXP(n, label, quiet){
  const before = level(S.xp);
  S.xp += n; touchStreak();
  if (!quiet) toast("+" + n + " XP  " + label);
  save(); updateHUD(); checkBadges();
  const after = level(S.xp);
  if (after > before) levelUp(after);
}
function applyGrade(id, g){
  const d = tday();
  const isNew = !S.cards[id];
  const c = Object.assign({box:0, due:d, seen:0, last:d}, S.cards[id]);
  if (g === "again") { c.box = 0; c.due = d; }
  else if (g === "hard") { c.box = Math.max(1, c.box); c.due = d + Math.max(1, Math.round(IV[c.box] / 2)); }
  else if (g === "good") { c.box = Math.min(MAXBOX, c.box + 1); c.due = d + IV[c.box]; }
  else { c.box = Math.min(MAXBOX, c.box + 2); c.due = d + IV[c.box]; }
  c.last = d; c.seen++;
  S.cards[id] = c; S.reviews++;
  S.days[d] = (S.days[d] || 0) + 1;
  if (isNew) { if (S.newDay.d !== d) S.newDay = {d, n:0}; S.newDay.n++; }
  Object.keys(S.days).forEach(k => { if (+k < d - 400) delete S.days[k]; });
  gainXP({again:1, hard:3, good:5, easy:6}[g], "card", true);
}

/* ================= modal & level up ================= */
function modal(html, onOpen){
  const o = $("#overlay");
  o.innerHTML = `<div class="modal" role="dialog" aria-modal="true">${html}</div>`;
  o.hidden = false;
  const close = () => { o.hidden = true; o.innerHTML = ""; };
  o.onclick = e => { if (e.target === o) close(); };
  if (onOpen) onOpen(o.querySelector(".modal"), close);
  const f = o.querySelector("[data-focus]") || o.querySelector("button");
  if (f) f.focus();
  return close;
}
function confirmBox(title, body, ok, danger){
  return new Promise(res => {
    modal(`<h2>${title}</h2><p class="muted">${body}</p><div class="row"><button class="btn" data-x="0">Cancel</button><button class="btn ${danger ? "danger" : "primary"}" data-x="1" data-focus>${ok}</button></div>`, (m, close) => {
      m.querySelectorAll("[data-x]").forEach(b => b.onclick = () => { close(); res(b.dataset.x === "1"); });
    });
  });
}
function levelUp(l){
  modal(`<div class="burst" aria-hidden="true">${Array.from({length:16}, (_, i) => `<i style="--a:${i * 22.5}deg"></i>`).join("")}</div>
    <div class="center"><p class="muted">Level up</p><div class="lvnum">Level ${l}</div><p style="margin-top:10px">You’re now a <strong>${rank(l)}</strong>. Keep the streak going.</p>
    <div class="row" style="justify-content:center"><button class="btn primary" data-close data-focus>Keep going</button></div></div>`, (m, close) => { m.querySelector("[data-close]").onclick = close; });
}

/* ================= preferences ================= */
const ROOT = document.documentElement;
const viewerTheme = ROOT.getAttribute("data-theme");
function applyPrefs(){
  const p = S.prefs;
  ROOT.dataset.accent = p.accent;
  ROOT.dataset.size = p.size;
  ROOT.dataset.motion = p.motion ? "on" : "off";
  if (p.theme === "light" || p.theme === "dark") ROOT.setAttribute("data-theme", p.theme);
  else if (viewerTheme) ROOT.setAttribute("data-theme", viewerTheme);
  else ROOT.removeAttribute("data-theme");
}
