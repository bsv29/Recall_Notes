/* ================= visuals: every topic gets a diagram ================= */
const shortPt = p => { const s = plain(p).replace(/`/g, ""); const lead = s.split(/[:.;]/)[0]; return lead.length > 46 ? lead.slice(0, 44).replace(/\s\S*$/, "") + "…" : lead; };
function autoVis(t){ return {type:"map", center:t.t, nodes:t.pts.slice(0, 4).map(shortPt)}; }
function visHTML(t){
  const v = t.vis || autoVis(t);
  const i = k => `style="--i:${k}"`;
  if (v.type === "flow" || v.type === "cycle") {
    return `<div class="vis vflow ${v.type === "cycle" ? "vcycle" : ""}">${v.steps.map((s, k) => `<div class="vnode" ${i(k)}><span class="vn">${k + 1}</span>${fmt(s)}</div>${k < v.steps.length - 1 ? `<span class="varrow" ${i(k)} aria-hidden="true">→</span>` : ""}`).join("")}${v.type === "cycle" ? `<span class="vloop" ${i(v.steps.length)}>↺ repeats</span>` : ""}</div>`;
  }
  if (v.type === "stack") return `<div class="vis vstack">${v.layers.map((l, k) => `<div class="vlayer" ${i(k)}>${fmt(l)}</div>`).join("")}</div>`;
  if (v.type === "compare") return `<div class="vis vcompare" style="--n:${v.cols.length}">${v.cols.map((c, k) => `<div class="vcol" ${i(k)}><div class="vch">${fmt(c.h)}</div><ul>${c.items.map(x => `<li>${fmt(x)}</li>`).join("")}</ul></div>`).join("")}</div>`;
  if (v.type === "grid") return `<div class="vis vgrid" style="--c:${v.cols}">${v.labels.map((l, k) => `<div class="vcell" ${i(k)}>${fmt(l)}</div>`).join("")}</div>`;
  if (v.type === "tree") return `<div class="vis vtree"><div class="vroot" ${i(0)}>${fmt(v.root)}</div><div class="vkids">${v.kids.map((kd, k) => { const node = typeof kd === "string" ? {n:kd, k:[]} : kd; return `<div class="vkid" ${i(k + 1)}><div class="vknode">${fmt(node.n)}</div>${(node.k || []).length ? `<ul>${node.k.map(x => `<li>${fmt(x)}</li>`).join("")}</ul>` : ""}</div>`; }).join("")}</div></div>`;
  return `<div class="vis vmap"><div class="vcenter" ${i(0)}>${esc(v.center)}</div><div class="vspokes">${v.nodes.map((n, k) => `<div class="vspoke" ${i(k + 1)}>${esc(n)}</div>`).join("")}</div></div>`;
}

/* ================= sidebar ================= */
function renderSide(){
  const due = reviewQueue().length;
  const cur = BYID[route] ? "" : route;
  const nav = (r, ic, label, extra) => `<a href="#${r}" data-go="${r}" class="${cur === r ? "on" : ""}">${icon(ic)}<span>${label}</span>${extra || ""}</a>`;
  const initial = (ME.name || "G").charAt(0).toUpperCase();
  $("#side").innerHTML = `<div class="brand"><span class="mark"><svg viewBox="0 0 24 24">${IC.brain}</svg></span>Recall</div>
    <nav class="nav">
      ${nav("dashboard", "home", "Dashboard")}
      ${nav("library", "grid", "All courses", `<span class="pct">${WORLDS.length}</span>`)}
      <div class="nav-h">Study</div>
      ${FORMATS.map(f => nav(f.id, f.icon, f.name, f.id === "revision" && due ? `<span class="count">${due}</span>` : "")).join("")}
      <div class="nav-h">You</div>
      ${nav("progress", "chart", "Progress")}
      ${nav("newskill", "plus", "Add a course")}
      ${nav("settings", "gear", "Settings")}
    </nav>
    <div class="side-foot"><span class="avatar sm">${esc(initial)}</span>
      <div class="who"><b>${esc(ME.name || "Guest")}</b><span id="sync" class="sync"></span></div>
      <button class="btn sm" id="signout" title="Sign out" aria-label="Sign out">${icon("out")}</button></div>`;
  paintSync();
  $("#signout").onclick = async () => { if (await confirmBox("Sign out?", "Your progress is saved to your account.", "Sign out")) { signOutLocal(); render(); } };
}

/* ================= course picker ================= */
let pickQuery = "";
function coursePicker(P, mode){
  const f = FMT[mode];
  const q = pickQuery.trim().toLowerCase();
  const usable = WORLDS.filter(w => w.formats.includes(mode) && w.topics.some(t => !t.planned && topicFormats(t).includes(mode)));
  const list = usable.filter(w => !q || w.name.toLowerCase().includes(q) || w.blurb.toLowerCase().includes(q));
  P.innerHTML = `<div class="phead"><div><div class="kicker">${icon(f.icon)}${f.name}</div><h1>Pick a course</h1><p>${f.desc}. Choose the course you want to study.</p></div></div>
    <div class="pick-search">${icon("search")}<input class="input" id="pickq" placeholder="Search courses" value="${esc(pickQuery)}" aria-label="Search courses"></div>
    ${CATS.map(cat => { const ws = list.filter(w => w.cat === cat.id); return ws.length ? `<h2 class="cat-h">${cat.name}</h2><div class="worldcards">${ws.map(w => { const s = worldStats(w); return `<button class="panel wcard" data-pick="${w.id}" style="--wc:${w.color}"><div class="row" style="justify-content:space-between"><span style="font-size:1.8rem">${w.icon}</span><span class="ring sm" style="--p:${s.mastery}"><span>${s.mastery}%</span></span></div><span class="wn">${esc(w.name)}</span><span class="muted small">${esc(w.blurb)}</span><span class="small" style="margin-top:auto">${w.topics.length} topics, ${s.learned} learned</span></button>`; }).join("")}</div>` : ""; }).join("")}
    ${list.length ? "" : `<div class="panel empty"><p class="muted">No course matches “${esc(pickQuery)}”.</p></div>`}`;
  const inp = $("#pickq");
  inp.oninput = () => { pickQuery = inp.value; const pos = inp.selectionStart; coursePicker(P, mode); const n = $("#pickq"); n.focus(); n.setSelectionRange(pos, pos); };
  P.querySelectorAll("[data-pick]").forEach(b => b.onclick = () => { S.modeCourse = Object.assign({}, S.modeCourse, {[mode]:b.dataset.pick}); save(); pickQuery = ""; renderPage(); window.scrollTo(0, 0); });
}

/* ================= mode pages ================= */
function modeHead(mode, w, extra){
  const f = FMT[mode];
  return `<div class="phead"><div><div class="kicker">${icon(f.icon)}${f.name}</div><h1>${w.icon} ${esc(w.name)}</h1><p>${esc(w.blurb)}</p></div>
    <div class="row">${extra || ""}<button class="btn" id="chcourse">${icon("grid")}Change course</button></div></div>`;
}
function levelPath(w, onPick, badge){
  const groups = ["B", "I", "A"].map(l => ({l, ts:w.topics.filter(t => (t.lvl || "B") === l)})).filter(g => g.ts.length);
  return groups.map(g => `<div class="lvl-group"><div class="lvl-h"><span class="lvl-tag lvl-${g.l}">${LVL[g.l]}</span><span class="muted small">${g.ts.length} topic${g.ts.length > 1 ? "s" : ""}</span></div>
    <div class="lvl-list">${g.ts.map(t => { const s = topicStats(t); return `<button class="lnode panel" data-topic="${t.id}" style="--wc:${w.color}"><span class="ring sm" style="--p:${s.mastery}"><span>${t.idx + 1}</span></span><span class="grow"><span class="lt">${esc(t.t)}</span><span class="ls">${t.planned ? "Not written yet" : fmt(t.hook)}</span></span>${badge(t, s)}</button>`; }).join("")}</div></div>`).join("");
}
function renderModePage(P, mode){
  const id = (S.modeCourse || {})[mode];
  const w = WORLDS.find(x => x.id === id);
  if (!w || !w.topics.some(t => !t.planned && topicFormats(t).includes(mode))) return coursePicker(P, mode);
  const ready = w.topics.filter(t => !t.planned && topicFormats(t).includes(mode));
  const back = () => { renderPage(); window.scrollTo(0, 0); };
  const sessHead = (title, sub) => `${crumbs([`<button data-go="${mode}">${FMT[mode].name}</button>`, `<span>${esc(w.name)}</span>`])}<div class="phead"><div><h1>${title}</h1><p>${sub}</p></div><button class="btn" id="sessback">Back to ${esc(w.name)}</button></div><div class="sess" id="sess"></div>`;
  const startSess = (title, sub, run) => { stopTimers(); keyHandler = null; P.innerHTML = sessHead(title, sub); $("#sessback").onclick = back; run($("#sess")); window.scrollTo(0, 0); };
  const stars = n => n ? `<span class="stars-sm">${"★".repeat(n)}${"☆".repeat(3 - n)}</span>` : "";
  if (mode === "notes") {
    const done = ready.filter(t => S.topics[t.id] && S.topics[t.id].learned).length;
    P.innerHTML = modeHead(mode, w) + `<div class="quest panel"><div><b>${done} of ${ready.length} levels cleared</b><div class="bar" style="margin-top:8px;--wc:${w.color}"><span style="width:${ready.length ? done / ready.length * 100 : 0}%"></span></div></div><span class="muted small">Read a topic, then pass its checkpoint to clear the level and earn XP.</span></div>` +
      levelPath(w, null, (t, s) => s.learned ? `<span class="pill strong">Cleared</span>` : t.planned ? `<span class="pill">Empty</span>` : `<span class="pill new">Start</span>`);
    P.querySelectorAll("[data-topic]").forEach(b => b.onclick = () => go(b.dataset.topic, {tab:"notes"}));
  } else if (mode === "cheat") {
    P.innerHTML = modeHead(mode, w, `<button class="btn" onclick="window.print()">${icon("print")}Print</button>`) + `<div class="sheet">${ready.map(cheatCard).join("")}</div>`;
  } else {
    const per = {revision:t => t.cards.length + " cards", interview:t => t.iq.length + " questions", quiz:t => t.quiz.length + " questions", practical:t => t.prac.length + " challenges"}[mode];
    const total = ready.reduce((a, t) => a + ({revision:t.cards, interview:t.iq, quiz:t.quiz, practical:t.prac}[mode]).length, 0);
    const actions = {
      revision:{label:"Study every card", sub:`${total} flashcards from ${esc(w.name)}. Your ratings schedule each card’s next review.`, run:el => cardSession(el, shuffle(ready.flatMap(t => t.cards.map((c, i) => cardItem(t, i)))), {showTopic:true, after:`<button class="btn primary" data-go="revision">Done</button>`})},
      interview:{label:"Start a mock interview", sub:"10 random questions. Answer as you would out loud, then compare with the model answer.", run:el => interviewSession(el, ready.flatMap(t => t.iq.map(q => ({q:q[0], a:q[1], topic:t.t, color:w.color, tid:t.id}))), {max:10, again:() => startSess("Mock interview", "", actions.interview.run)})},
      quiz:{label:"Mixed quiz", sub:"Up to 15 questions from every topic, with combo multipliers.", run:el => quizSession(el, shuffle(ready.flatMap(t => t.quiz.map(q => prepQ(t, q)))).slice(0, 15), {again:() => startSess("Mixed quiz", "", actions.quiz.run)})},
      practical:{label:"Arena run", sub:"8 timed challenges from the whole course. 3 lives, combos and stars.", run:el => arenaSession(el, shuffle(ready.flatMap(t => t.prac.map(c => Object.assign({topic:t.t, color:w.color}, c)))), {max:8, again:() => startSess("Arena run", "", actions.practical.run)})}
    }[mode];
    const due = mode === "revision" ? reviewQueue().length : 0;
    P.innerHTML = modeHead(mode, w) + `
      ${mode === "revision" ? `<div class="banner"><div><h3>Daily review: ${due} card${due === 1 ? "" : "s"} due</h3><p class="muted" style="margin:0">Cards due today from every course, spaced so they come back just before you’d forget.</p></div><button class="btn primary" data-go="review" ${due ? "" : "disabled"}>Start daily review</button></div>` : ""}
      <div class="hero-mode panel" style="--wc:${w.color}"><div><h2>${actions.label}</h2><p class="muted" style="margin:.3em 0 0">${actions.sub}</p></div><div class="row"><button class="btn primary lg" id="bigstart">${icon(FMT[mode].icon)}Start</button>${mode === "quiz" && ready.reduce((a, t) => a + t.quiz.length, 0) >= 4 ? `<button class="btn lg" data-boss="${w.id}">${icon("bolt")}Boss battle</button>` : ""}</div></div>
      <h2 class="cat-h">Or pick a topic</h2>` + levelPath(w, null, (t, s) => t.planned || !topicFormats(t).includes(mode) ? `<span class="pill">—</span>` : `<span class="muted small">${per(t)}</span>${mode === "practical" ? stars((S.topics[t.id] || {}).stars) : mode === "quiz" && (S.topics[t.id] || {}).quiz != null ? `<span class="pill">${S.topics[t.id].quiz}%</span>` : ""}`);
    $("#bigstart").onclick = () => startSess(actions.label + ": " + esc(w.name), actions.sub, actions.run);
    P.querySelectorAll("[data-topic]").forEach(b => b.onclick = () => { const t = BYID[b.dataset.topic]; if (t.planned || !topicFormats(t).includes(mode)) return go(t.id); go(t.id, {tab:mode}); });
  }
  const cc = $("#chcourse"); if (cc) cc.onclick = () => { S.modeCourse = Object.assign({}, S.modeCourse, {[mode]:null}); save(); renderPage(); };
}

/* ================= library ================= */
function renderLibrary(P){
  const q = pickQuery.trim().toLowerCase();
  const list = WORLDS.filter(w => !q || w.name.toLowerCase().includes(q) || w.blurb.toLowerCase().includes(q));
  P.innerHTML = `<div class="phead"><div><h1>All courses</h1><p>${BUILTIN.length} built-in courses with ${BUILTIN.reduce((a, w) => a + w.topics.length, 0)} topics, from basic to advanced, plus your own.</p></div><button class="btn primary" data-go="newskill">${icon("plus")}Add a course</button></div>
    <div class="pick-search">${icon("search")}<input class="input" id="pickq" placeholder="Search courses" value="${esc(pickQuery)}" aria-label="Search courses"></div>
    ${CATS.map(cat => { const ws = list.filter(w => w.cat === cat.id); return ws.length ? `<h2 class="cat-h">${cat.name}</h2><div class="worldcards">${ws.map(w => { const s = worldStats(w); return `<button class="panel wcard" data-go="${w.id}" style="--wc:${w.color}"><div class="row" style="justify-content:space-between"><span style="font-size:1.8rem">${w.icon}</span><span class="ring sm" style="--p:${s.mastery}"><span>${s.mastery}%</span></span></div><span class="wn">${esc(w.name)}</span><span class="muted small">${esc(w.blurb)}</span><span class="small" style="margin-top:auto">${w.topics.length} topics, ${s.learned} learned</span></button>`; }).join("")}</div>` : ""; }).join("")}`;
  const inp = $("#pickq");
  inp.oninput = () => { pickQuery = inp.value; const pos = inp.selectionStart; renderLibrary(P); const n = $("#pickq"); n.focus(); n.setSelectionRange(pos, pos); };
}

/* ================= checkpoint (gamified notes) ================= */
function checkpointHTML(t){
  if (!t.quiz.length) return "";
  const rec = S.topics[t.id] || {};
  return `<section class="panel section checkpoint" id="cp"><div class="shead"><h2>${icon("bolt")}Checkpoint</h2>${rec.learned ? `<span class="pill strong">Level cleared</span>` : `<span class="muted small">Answer correctly to clear this level, +25 XP</span>`}</div><div id="cpbody"></div></section>`;
}
function runCheckpoint(t){
  const body = $("#cpbody"); if (!body) return;
  const q = prepQ(t, t.quiz[Math.floor(Math.random() * t.quiz.length)]);
  body.innerHTML = `<p class="qq" style="margin:.2em 0 .8em">${fmt(q.q)}</p><div class="opts">${q.opts.map((o, k) => `<button class="opt ${isCodey(o) ? "mono" : ""}" data-k="${k}"><span class="key">${"ABCD"[k]}</span><span>${esc(o)}</span></button>`).join("")}</div><div class="explain" hidden></div>`;
  body.querySelectorAll(".opt").forEach(b => b.onclick = () => {
    const k = +b.dataset.k, ok = k === q.ans;
    body.querySelectorAll(".opt").forEach((x, j) => { x.disabled = true; if (j === q.ans) x.classList.add("right"); else if (j === k) x.classList.add("wrong"); });
    const ex = body.querySelector(".explain"); ex.hidden = false;
    const rec = S.topics[t.id] = S.topics[t.id] || {};
    if (ok && !rec.learned) {
      rec.learned = true; gainXP(25, "level cleared");
      ex.innerHTML = `<p><strong style="color:var(--good)">Level cleared!</strong> ${fmt(q.exp)} Its flashcards are now in your daily review.</p>`;
      const next = t.world.topics[t.idx + 1];
      if (next) ex.innerHTML += `<button class="btn primary" data-go="${next.id}">Next level: ${esc(next.t)}</button>`;
      renderSide();
    } else if (ok) {
      ex.innerHTML = `<p><strong style="color:var(--good)">Correct.</strong> ${fmt(q.exp)}</p><button class="btn" id="cpagain">Another question</button>`;
    } else {
      ex.innerHTML = `<p><strong style="color:var(--bad)">Not quite.</strong> ${fmt(q.exp)} Reread the key points, then try again.</p><button class="btn primary" id="cpagain">Try again</button>`;
    }
    const ag = $("#cpagain"); if (ag) ag.onclick = () => runCheckpoint(t);
  });
}


/* ================= full lessons ================= */
function lessonBlock(b){
  if (typeof b === "string") return `<p>${fmt(b)}</p>`;
  if (b.sub) return `<h3 class="lsub">${fmt(b.sub)}</h3>`;
  if (b.code != null) return `<div class="codewrap lcode"><div class="codehead"><span>Example</span><button class="copy" data-copy>Copy</button></div><pre><code>${hl(b.code)}</code></pre>${b.out ? `<div class="lout"><span>Output</span><pre>${esc(b.out)}</pre></div>` : ""}</div>`;
  if (b.tip) return `<div class="callout tip"><b>Tip</b><span>${fmt(b.tip)}</span></div>`;
  if (b.warn) return `<div class="callout warn"><b>Watch out</b><span>${fmt(b.warn)}</span></div>`;
  if (b.list) return `<ul class="llist">${b.list.map(x => `<li>${fmt(x)}</li>`).join("")}</ul>`;
  if (b.table) return `<div class="tbl-wrap ltable"><table class="table"><thead><tr>${b.table.head.map(h => `<th>${fmt(h)}</th>`).join("")}</tr></thead><tbody>${b.table.rows.map(r => `<tr>${r.map(c => `<td>${fmt(c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
  return "";
}
function lessonHTML(t){
  const secs = t.doc || [];
  const read = (S.topics[t.id] || {}).read || [];
  return `<nav class="panel toc"><div class="kicker">${icon("notes")}In this lesson, ${secs.length} sections</div><ol>${secs.map((s, i) => `<li><button class="link" data-sec="${i}">${esc(s.h)}</button>${read.includes(i) ? ` <span class="okmark" title="Read">✓</span>` : ""}</li>`).join("")}</ol></nav>
  ${secs.map((s, i) => `<section class="panel lesson" id="sec-${i}"><h2><span class="secnum">${i + 1}</span>${esc(s.h)}</h2>${s.b.map(lessonBlock).join("")}
    <div class="lfoot"><button class="btn sm ${read.includes(i) ? "" : "primary"}" data-read="${i}">${read.includes(i) ? "Read ✓" : "Mark section as read, +5 XP"}</button></div></section>`).join("")}`;
}
function wireLesson(el, t){
  el.querySelectorAll("[data-sec]").forEach(b => b.onclick = () => { const s = document.getElementById("sec-" + b.dataset.sec); if (s) s.scrollIntoView({behavior:"smooth", block:"start"}); });
  el.querySelectorAll("[data-copy]").forEach(b => b.onclick = async () => { const code = b.closest(".codewrap").querySelector("code").innerText; try { await navigator.clipboard.writeText(code); b.textContent = "Copied"; } catch (e) { b.textContent = "Select to copy"; } });
  el.querySelectorAll("[data-read]").forEach(b => b.onclick = () => {
    const i = +b.dataset.read, rec = S.topics[t.id] = S.topics[t.id] || {};
    rec.read = rec.read || [];
    if (rec.read.includes(i)) return;
    rec.read.push(i); gainXP(5, "section read", true); save();
    b.textContent = "Read ✓"; b.classList.remove("primary");
    const tocItem = el.querySelector(`[data-sec="${i}"]`); if (tocItem && !tocItem.nextElementSibling) tocItem.insertAdjacentHTML("afterend", ` <span class="okmark">✓</span>`);
    const next = document.getElementById("sec-" + (i + 1)) || document.getElementById("cp");
    if (next) next.scrollIntoView({behavior:"smooth", block:"start"});
  });
}
