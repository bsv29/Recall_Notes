/* ================= routing ================= */
let editingTopic = null, route = "dashboard", topicTab = "notes", genBusy = {}, genErr = {}, genQueue = {running:false}, keyHandler = null, recallMode = false, reviewMode = "daily", csWorld = "python", csLearnedOnly = false, onbGoal = null, onbFocus = null;
const PAGES = ["dashboard", "review", "library", "cheatsheets", "progress", "settings", "newskill", "editskill", "notes", "cheat", "revision", "interview", "quiz", "practical"];
const validRoute = r => PAGES.includes(r) || WORLDS.some(w => w.id === r) || !!BYID[r];
function go(r, opts){
  if (r !== route) editingTopic = null;
  if (BYID[r] && r !== route) topicTab = (opts && opts.tab) || "notes";
  if (r === "editskill" && !wiz) r = "library";
  else if (BYID[r] && opts && opts.tab) topicTab = opts.tab;
  if (r === "review") reviewMode = (opts && opts.mode) || "daily";
  route = validRoute(r) ? r : "dashboard";
  closeNav();
  renderPage();
  window.scrollTo(0, 0);
  try { history.replaceState(null, "", "#" + route); } catch (e) {}
}
function render(){
  applyPrefs();
  keyHandler = null;
  if (!ME.id) return renderAuth();
  if (!S.onboarded) return renderOnboard();
  if (!$(".shell")) buildShell();
  renderPage();
}

/* ================= auth ================= */
const curveSVG = `<svg viewBox="0 0 420 190" role="img" aria-label="Forgetting curve: memory drops quickly without review; each spaced review resets it and the decay gets slower.">
  <line x1="24" y1="170" x2="410" y2="170" stroke="#2B3150" stroke-width="1.5"/>
  <line x1="24" y1="14" x2="24" y2="170" stroke="#2B3150" stroke-width="1.5"/>
  <text x="30" y="12" fill="#7E869C" font-size="10" font-family="Atkinson Hyperlegible,sans-serif">memory</text>
  <text x="372" y="184" fill="#7E869C" font-size="10" font-family="Atkinson Hyperlegible,sans-serif">time</text>
  <path class="draw" d="M24,22 C70,110 140,150 408,164" fill="none" stroke="#F06B6F" stroke-width="2.5" stroke-dasharray="6 6"/>
  <path class="draw" d="M24,22 C40,62 56,72 72,76 L72,22 C104,56 124,62 146,64 L146,22 C192,46 222,51 256,52 L256,22 C318,34 360,37 408,38" fill="none" stroke="var(--acc)" stroke-width="3" stroke-linejoin="round"/>
  <g fill="var(--acc)"><circle cx="72" cy="22" r="4"/><circle cx="146" cy="22" r="4"/><circle cx="256" cy="22" r="4"/></g>
  <g fill="#B9C0D4" font-size="10" font-family="Atkinson Hyperlegible,sans-serif"><text x="56" y="16">day 1</text><text x="130" y="16">day 3</text><text x="240" y="16">day 7</text></g>
</svg>`;
let authTab = "signin", authErr = "", authEmail = "";
function renderAuth(){
  closeNav();
  $("#root").innerHTML = `<div class="auth">
    <section class="auth-art">
      <div class="brand"><span class="mark"><svg viewBox="0 0 24 24">${IC.brain}</svg></span>Recall</div>
      <h1>Learn it once. Still know it in three months.</h1>
      <p class="sub">Notes, cheat sheets, flashcards, quizzes, mock interviews and code challenges for 20 courses, scheduled so each review lands right before you’d forget.</p>
      <figure class="curve" style="margin:0"><div>${curveSVG}</div>
        <figcaption class="cap"><span><i style="background:#F06B6F"></i>Read once, never reviewed</span><span><i style="background:var(--acc)"></i>Reviewed on day 1, 3 and 7</span></figcaption></figure>
    </section>
    <section class="auth-panel"><div class="auth-card">
      <div class="seg authseg" role="tablist"><button class="${authTab === "signin" ? "on" : ""}" data-at="signin">Sign in</button><button class="${authTab === "signup" ? "on" : ""}" data-at="signup">Create account</button></div>
      ${authTab === "signin" ? `
        <h2 style="margin-top:20px">Welcome back</h2>
        <p class="muted small">Your progress syncs across every device you sign in on.</p>
        <form id="authform" novalidate>
          <label class="lbl" for="em">Email</label><input class="input" id="em" type="email" autocomplete="username" value="${esc(authEmail)}" required>
          <label class="lbl" for="pw" style="margin-top:12px">Password</label><input class="input" id="pw" type="password" autocomplete="current-password" required>
          ${authErr ? `<p class="formerr">${esc(authErr)}</p>` : ""}
          <button class="btn primary lg" style="margin-top:16px" type="submit" id="authbtn">Sign in</button>
        </form>
        <p class="fine">Have a backup file? <label class="link" for="restorefile" style="cursor:pointer">Restore it into a new account</label><input type="file" id="restorefile" accept=".json,application/json" hidden></p>`
      : `
        <h2 style="margin-top:20px">Create your account</h2>
        <p class="muted small">Free, and it takes ten seconds.</p>
        <form id="authform" novalidate>
          <label class="lbl" for="nm">Name</label><input class="input" id="nm" autocomplete="name" required>
          <label class="lbl" for="em" style="margin-top:12px">Email</label><input class="input" id="em" type="email" autocomplete="username" required>
          <label class="lbl" for="pw" style="margin-top:12px">Password</label><input class="input" id="pw" type="password" autocomplete="new-password" minlength="8" required>
          <label class="lbl" for="pw2" style="margin-top:12px">Confirm password</label><input class="input" id="pw2" type="password" autocomplete="new-password" required>
          ${authErr ? `<p class="formerr">${esc(authErr)}</p>` : ""}
          <button class="btn primary lg" style="margin-top:16px" type="submit" id="authbtn">Create account</button>
        </form>`}
    </div></section></div>`;
  document.querySelectorAll("[data-at]").forEach(b => b.onclick = () => { authTab = b.dataset.at; authErr = ""; renderAuth(); });
  $("#authform").onsubmit = async e => {
    e.preventDefault();
    const em = $("#em").value.trim().toLowerCase(), pw = $("#pw").value, btn = $("#authbtn");
    try {
      if (authTab === "signin") {
        if (!em || !pw) throw new Error("Enter your email and password.");
        btn.disabled = true; btn.textContent = "Signing in…";
        await signIn(em, pw);
      } else {
        const nm = $("#nm").value.trim();
        if (!nm) throw new Error("Enter your name.");
        if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em)) throw new Error("Enter a valid email address.");
        if (pw.length < 8) throw new Error("Use a password of at least 8 characters.");
        if (pw !== $("#pw2").value) throw new Error("The two passwords don’t match.");
        btn.disabled = true; btn.textContent = "Creating account…";
        await createAccount(nm, em, pw);
        if (pendingRestore) {
          const file = pendingRestore; pendingRestore = null;
          importBackup(file, ok => { toast(ok ? "Backup restored" : "Couldn’t read that backup", ok); renderPage(); });
        } else toast("Account created. Welcome, " + nm.split(" ")[0] + "!", true);
      }
      authErr = ""; authEmail = "";
      const sr = S.lastRoute;
      route = sr && validRoute(sr) && sr !== "editskill" ? sr : "dashboard";
      render();
    } catch (err) { authErr = err.message; authEmail = em; renderAuth(); }
  };
  const rf = $("#restorefile");
  if (rf) rf.onchange = () => {
    const file = rf.files[0]; if (!file) return;
    const r = new FileReader();
    r.onload = () => {
      try {
        const d = JSON.parse(r.result); if (d.app !== "recall") throw 0;
        authTab = "signup"; authErr = ""; renderAuth();
        $("#nm").value = (d.account && d.account.name) || ""; $("#em").value = (d.account && d.account.email) || "";
        pendingRestore = file;
        toast("Choose a password to finish restoring");
      } catch (e) { authErr = "That file isn’t a Recall backup."; renderAuth(); }
    };
    r.readAsText(file);
  };
  const first = $("#em") && !$("#em").value ? $("#em") : $("#pw");
  if (first) first.focus();
}
let pendingRestore = null;
function renderOnboard(){
  if (onbGoal == null) onbGoal = S.prefs.goal;
  if (onbFocus == null) onbFocus = S.focus.slice();
  const goals = [[10, "Light", "About 5 minutes a day"], [20, "Steady", "About 10 minutes a day"], [40, "Intense", "About 20 minutes a day"]];
  $("#root").innerHTML = `<div class="auth"><section class="auth-art">
      <div class="brand"><span class="mark"><svg viewBox="0 0 24 24">${IC.brain}</svg></span>Recall</div>
      <h1>Set a pace you can keep.</h1>
      <p class="sub">Small daily reviews beat long sessions. You can change all of this later in Settings.</p>
      <figure class="curve" style="margin:0">${curveSVG}</figure>
    </section>
    <section class="auth-panel"><div class="auth-card">
      <p class="muted small">Step 2 of 2</p>
      <h2>Your study plan</h2>
      <label class="lbl" style="margin-top:18px">Daily review goal</label>
      <div class="choice">${goals.map(g => `<button class="opt-card ${onbGoal === g[0] ? "on" : ""}" data-goal="${g[0]}"><div><b>${g[1]}, ${g[0]} cards</b><small>${g[2]}</small></div></button>`).join("")}</div>
      <label class="lbl">What are you studying?</label>
      <div class="chips">${BUILTIN.map(w => `<button class="chip ${onbFocus.includes(w.id) ? "on" : ""}" style="--wc:${w.color}" data-focus-w="${w.id}"><span class="dot"></span>${w.name}</button>`).join("")}</div>
      <button class="btn primary lg" id="startbtn">Start learning</button>
      <p class="fine"><button class="link" id="backbtn">Sign out</button></p>
    </div></section></div>`;
  document.querySelectorAll("[data-goal]").forEach(b => b.onclick = () => { onbGoal = +b.dataset.goal; renderOnboard(); });
  document.querySelectorAll("[data-focus-w]").forEach(b => b.onclick = () => { const id = b.dataset.focusW; onbFocus = onbFocus.includes(id) ? onbFocus.filter(x => x !== id) : onbFocus.concat(id); if (!onbFocus.length) onbFocus = [id]; renderOnboard(); });
  $("#startbtn").onclick = () => { S.prefs.goal = onbGoal; S.focus = onbFocus; S.onboarded = true; save(); render(); };
  $("#backbtn").onclick = () => { signOutLocal(); render(); };
}

/* ================= shell ================= */
function buildShell(){
  $("#root").innerHTML = `<div class="shell">
    <aside class="side" id="side" aria-label="Main navigation"></aside>
    <div class="scrim" id="scrim"></div>
    <div class="main">
      <header class="top">
        <button class="btn ghost sm menu" id="menubtn" aria-label="Open menu">${icon("menu")}</button>
        <div class="ttl" id="ttl"></div>
        <div class="search" role="search">${icon("search")}<input class="input" id="q" placeholder="Search topics and cards" autocomplete="off" aria-label="Search"><kbd>/</kbd><div class="results" id="results" hidden></div></div>
        <button class="hudchip hide-sm" data-go="progress" title="Day streak">${icon("fire")}<span id="hstreak">0</span></button>
        <button class="hudchip" data-go="progress" title="Level"><b id="hlvl">Lv 1</b><span class="bar"><span id="hxp"></span></span></button>
      </header>
      <main class="page" id="page"></main>
    </div></div>`;
  $("#menubtn").onclick = () => { $("#side").classList.add("open"); $("#scrim").classList.add("open"); };
  $("#scrim").onclick = closeNav;
  setupSearch();
}
function closeNav(){ const s = $("#side"); if (s) { s.classList.remove("open"); $("#scrim").classList.remove("open"); } }
function updateHUD(){
  if (!$("#hlvl")) return;
  const l = level(S.xp), a = lvlStart(l), b = lvlEnd(l);
  $("#hlvl").textContent = "Lv " + l;
  $("#hxp").style.width = ((S.xp - a) / (b - a) * 100) + "%";
  $("#hstreak").textContent = currentStreak();
}
const TITLES = {dashboard:"Dashboard", review:"Daily review", library:"All courses", cheatsheets:"Cheat sheets", progress:"Progress", settings:"Settings", newskill:"Add a course", editskill:"Edit course", notes:"Notes", cheat:"Cheat sheet", revision:"Revision", interview:"Interview", quiz:"Quiz", practical:"Practical"};
function renderPage(){
  if (!ME.id || !S.onboarded) return render();
  if (!$(".shell")) buildShell();
  keyHandler = null; stopTimers();
  if (S.lastRoute !== route && route !== "editskill") { S.lastRoute = route; save(); }
  const w = WORLDS.find(x => x.id === route);
  $("#ttl").textContent = TITLES[route] || (w ? w.name : BYID[route] ? BYID[route].t : "");
  renderSide(); updateHUD();
  const P = $("#page");
  if (route === "review") renderReview(P);
  else if (FMT[route]) renderModePage(P, route);
  else if (route === "library") renderLibrary(P);
  else if (route === "cheatsheets") renderCheats(P);
  else if (route === "progress") renderProgress(P);
  else if (route === "settings") renderSettings(P);
  else if (route === "newskill" || route === "editskill") renderWizard(P);
  else if (w) renderWorld(P, w);
  else if (BYID[route]) renderTopic(P, BYID[route]);
  else renderDashboard(P);
}
const crumbs = parts => `<nav class="crumbs" aria-label="Breadcrumb"><button data-go="dashboard">Dashboard</button>${parts.map(p => `<span aria-hidden="true">/</span>${p}`).join("")}</nav>`;

/* ================= dashboard ================= */
function heatmap(){
  const d = tday(), dow = new Date().getDay(), weeks = 16;
  const start = d - ((weeks - 1) * 7 + dow);
  let cells = "";
  for (let k = 0; k < weeks * 7; k++) {
    const day = start + k, n = S.days[day] || 0;
    const lv = day > d ? "fut" : n === 0 ? "" : n < 6 ? "l1" : n < 16 ? "l2" : n < 31 ? "l3" : "l4";
    cells += `<i class="${lv}" title="${dayLabel(day)}: ${n} cards"></i>`;
  }
  return `<div class="heat" aria-label="Review activity, last 16 weeks">${cells}</div>`;
}
function renderDashboard(P){
  const hr = new Date().getHours();
  const greet = hr < 12 ? "Good morning" : hr < 17 ? "Good afternoon" : "Good evening";
  const first = ME.name ? ", " + ME.name.split(" ")[0] : "";
  const due = reviewQueue(), done = reviewedToday(), goal = S.prefs.goal;
  const pct = Math.min(100, Math.round(done / goal * 100));
  const gap = S.last != null && S.last !== tday() ? tday() - S.last : (S.prevLast != null && S.last === tday() ? 0 : 0);
  const awayDays = S.last != null ? tday() - S.last : 0;
  const fadingCards = Object.values(S.cards).filter(c => cardR(c) < 0.8).length;
  const fading = ALL.map(t => ({t, s:topicStats(t)})).filter(x => x.s.ret != null).sort((a, b) => a.s.ret - b.s.ret).slice(0, 5);
  const nextUp = ALL.filter(t => !t.world.custom && S.focus.includes(t.world.id) && !(S.topics[t.id] && S.topics[t.id].learned)).slice(0, 4);
  const hpool = ALL.filter(t => t.hook); const hk = hpool[tday() % hpool.length];
  const l = level(S.xp), a = lvlStart(l), b = lvlEnd(l);
  P.innerHTML = `<div class="phead"><div><h1>${greet}${esc(first)}</h1><p>${new Date().toLocaleDateString(undefined, {weekday:"long", month:"long", day:"numeric"})}. ${due.length ? `${due.length} card${due.length > 1 ? "s" : ""} waiting for you.` : learnedCount() ? "You’re all caught up." : "Start with your first topic below."}</p></div>
    <div class="row">${due.length ? `<button class="btn primary" data-go="review">${icon("review")}Start review</button>` : ""}<button class="btn" data-go="library">${icon("grid")}All courses</button></div></div>
  ${awayDays >= 7 && fadingCards ? `<div class="banner"><div><h3>Welcome back. It’s been ${awayDays} days.</h3><p class="muted" style="margin:0">${fadingCards} card${fadingCards > 1 ? "s have" : " has"} faded below 80% recall. A short catch-up, weakest cards first, restores most of it.</p></div><button class="btn primary" id="catchup">Start catch-up</button></div>` : ""}
  <div class="modestrip">${FORMATS.map(f => `<button class="mstrip" data-mode="${f.id}">${icon(f.icon)}<span><b>${f.name}</b><small>${f.desc}</small></span></button>`).join("")}</div>
  <div class="grid g3">
    <section class="panel pad"><div class="kicker">${icon("review")}Today</div>
      <div class="today"><div class="ring" style="--p:${pct}"><span>${done}<br><small class="muted">of ${goal}</small></span></div>
      <div><div class="big">${due.length}</div><div class="muted small">cards due now</div>
      <button class="link" style="margin-top:8px" data-go="${due.length ? "review" : (nextUp[0] ? nextUp[0].id : "library")}">${due.length ? "Review now" : "Learn something new"}</button></div></div></section>
    <section class="panel pad"><div class="kicker">${icon("fire")}Streak</div>
      <div class="row" style="align-items:baseline;gap:8px"><span class="big">${currentStreak()}</span><span class="muted">days, best ${S.best || currentStreak()}</span></div>${heatmap()}</section>
    <section class="panel pad"><div class="kicker">${icon("bolt")}Level ${l}</div>
      <div class="big" style="font-size:1.6rem">${rank(l)}</div>
      <div class="bar" style="margin:12px 0 6px"><span style="width:${(S.xp - a) / (b - a) * 100}%"></span></div>
      <div class="muted small">${S.xp - a} of ${b - a} XP to level ${l + 1}</div>
      <button class="link" style="margin-top:8px" data-go="progress">See badges</button></section>
  </div>
  <div class="grid g2" style="margin-top:16px">
    <section class="panel pad"><div class="shead"><h2>Memory health</h2><span class="muted small">Estimated recall today</span></div>
      <div class="health">${WORLDS.filter(w => w.topics.length).map(w => { const s = worldStats(w); const r = s.ret == null ? null : Math.round(s.ret * 100);
        return `<div class="hrow" style="--wc:${w.color}"><span class="nm"><span class="dot"></span>${w.name}</span><div class="bar"><span style="width:${r || 0}%"></span></div><span class="v">${r == null ? "–" : r + "%"}</span></div>`; }).join("")}</div>
      <p class="muted small" style="margin:14px 0 0">Recall drops between reviews. Each correct answer makes the next drop slower, so cards come back after 1, 3, 7, 16, 35, 75 and finally 150 days.</p></section>
    <section class="panel pad"><div class="shead"><h2>Fading soon</h2>${fading.length ? `<button class="link" id="catchup2">Refresh all</button>` : ""}</div>
      ${fading.length ? `<div class="list">${fading.map(x => `<button class="li" data-go-tab="${x.t.id}|revision" style="--wc:${x.t.world.color}"><span class="dot"></span><span class="grow"><span class="lt">${esc(x.t.t)}</span><br><span class="ls">${x.t.world.name}</span></span>${pill(x.s.status)}<b>${Math.round(x.s.ret * 100)}%</b></button>`).join("")}</div>`
        : `<p class="muted">Nothing yet. Topics appear here once you’ve reviewed their flashcards, sorted by how close they are to being forgotten.</p>`}</section>
  </div>
  <div class="grid g2" style="margin-top:16px">
    <section class="panel pad"><div class="shead"><h2>Up next</h2><button class="link" data-go="library">Open library</button></div>
      ${nextUp.length ? `<div class="list">${nextUp.map(t => `<button class="li" data-go="${t.id}" style="--wc:${t.world.color}"><span class="dot"></span><span class="grow"><span class="lt">${esc(t.t)}</span><br><span class="ls">${t.world.name}, topic ${t.idx + 1}</span></span></button>`).join("")}</div>` : `<p class="muted">You’ve learned every topic in your focus areas. Try a boss battle, or pick another course.</p>`}</section>
    <section class="panel hook-day" style="--wc:${hk.world.color}"><div class="kicker">Hook of the day, ${hk.world.name}</div><p class="hk">${fmt(hk.hook)}</p><button class="link" data-go="${hk.id}">Open ${esc(hk.t)}</button></section>
  </div>`;
  const cu = () => go("review", {mode:"catchup"});
  if ($("#catchup")) $("#catchup").onclick = cu;
  if ($("#catchup2")) $("#catchup2").onclick = cu;
}

/* ================= library & skills ================= */
function renderWorld(P, w){
  const s = worldStats(w);
  const planned = w.topics.filter(t => t.planned).length;
  if (w.custom && !w.topics.length) {
    P.innerHTML = `${crumbs([`<span>${esc(w.name)}</span>`])}<div class="panel empty"><span style="font-size:2rem">${w.icon}</span><h2 style="margin:10px 0 6px">No topics yet</h2><p class="muted">Add topics to this course, then write notes for them.</p><div class="row" style="justify-content:center"><button class="btn primary" data-edit="${w.id}">${icon("edit")}Add topics</button></div></div>`;
    return;
  }
  const qn = w.topics.reduce((a, t) => a + t.quiz.length, 0);
  const fmts = w.formats.map(f => FMT[f].name).join(", ");
  P.innerHTML = `${crumbs([`<span>${esc(w.name)}</span>`])}
  <section class="panel whero" style="--wc:${w.color}"><span class="wi">${w.icon}</span><div><h1>${esc(w.name)}</h1><p class="muted" style="margin:.3em 0 0">${esc(w.blurb)}${w.custom ? "" : ". Work through the topics in order."}</p>${w.custom ? `<p class="muted small" style="margin:.4em 0 0">Formats: ${fmts}</p>` : ""}</div>
    <div class="stats"><div class="stat"><b>${s.learned}/${w.topics.length}</b><span>learned</span></div><div class="stat"><b>${s.mastery}%</b><span>mastery</span></div><div class="stat"><b>${s.ret == null ? "–" : Math.round(s.ret * 100) + "%"}</b><span>recall today</span></div></div></section>
  ${planned ? `<div class="banner"><div><h3>${planned} topic${planned > 1 ? "s" : ""} still empty</h3><p class="muted" style="margin:0">Open a topic and write its notes, flashcards and questions.</p></div></div>` : ""}
  <div class="row" style="margin:16px 0">
    <button class="btn primary" data-boss="${w.id}" ${qn < 4 ? "disabled" : ""}>${icon("bolt")}Boss battle</button>
    ${["notes", "quiz", "practical", "interview", "revision"].filter(m => w.formats.includes(m)).map(m => `<button class="btn" data-modego="${m}|${w.id}">${icon(FMT[m].icon)}${FMT[m].name}</button>`).join("")}
    ${w.formats.includes("cheat") ? `<button class="btn" data-cs="${w.id}">${icon("sheet")}Cheat sheet</button>` : ""}
    ${w.custom ? `<button class="btn" data-edit="${w.id}">${icon("edit")}Edit course</button>` : ""}</div>
  <div class="panel tbl-wrap"><table class="table"><thead><tr><th>#</th><th>Topic</th><th>Level & status</th><th>Memory strength</th><th>Mastery</th></tr></thead><tbody>
  ${w.topics.map((t, i) => { const ts = topicStats(t); const busy = genBusy[t.id];
    return `<tr data-go="${t.id}" tabindex="0"><td class="num">${i + 1}</td><td><div class="tt">${esc(t.t)}</div><div class="th">${t.planned ? "Empty: open it to write notes" : fmt(t.hook)}</div></td>
      <td><span class="lvl-tag lvl-${t.lvl || "B"}">${LVL[t.lvl || "B"]}</span> ${pill(ts.status)}</td><td>${meter(ts.avgBox, w.color)}</td><td><b>${ts.mastery}%</b></td></tr>`; }).join("")}
  </tbody></table></div>`;
  P.querySelectorAll("tr[data-go]").forEach(tr => tr.onkeydown = e => { if (e.key === "Enter") go(tr.dataset.go); });
}

/* ================= topic ================= */
function cheatCard(t){
  return `<article class="panel cs" style="--wc:${t.world.color}"><h3>${esc(t.t)}</h3>${t.hook ? `<p class="hk">${fmt(t.hook)}</p>` : ""}
    <ul>${t.pts.map(p => `<li>${fmt(p)}</li>`).join("")}</ul>
    ${t.traps.length ? `<div class="tr">${t.traps.map(x => "⚠ " + fmt(x)).join("<br>")}</div>` : ""}
    ${t.code ? `<pre><code>${hl(t.code)}</code></pre>` : ""}</article>`;
}
function renderTopic(P, t){
  if (S.lastTopic !== t.id) { S.lastTopic = t.id; save(); }
  const w = t.world, prev = w.topics[t.idx - 1], next = w.topics[t.idx + 1], ts = topicStats(t);
  const fm = topicFormats(t);
  if (!fm.includes(topicTab)) topicTab = fm[0] || "notes";
  const count = {revision:t.cards.length, interview:t.iq.length, quiz:t.quiz.length, practical:t.prac.length};
  P.innerHTML = `${crumbs([`<button data-go="${w.id}">${esc(w.name)}</button>`, `<span>${esc(t.t)}</span>`])}
  <div class="phead" style="margin-bottom:0"><div><h1>${esc(t.t)}</h1><p>${esc(w.name)}, level ${t.idx + 1} of ${w.topics.length} <span class="lvl-tag lvl-${t.lvl || "B"}">${LVL[t.lvl || "B"]}</span></p></div>${pill(ts.status)}</div>
  ${t.planned ? "" : `<div class="modes" role="tablist" style="--wc:${w.color}">${fm.map(k => `<button role="tab" class="mode ${topicTab === k ? "on" : ""}" aria-selected="${topicTab === k}" data-tab="${k}">${icon(FMT[k].icon)}<span>${FMT[k].name}</span>${count[k] ? `<small>${count[k]}</small>` : ""}</button>`).join("")}</div>`}
  <div id="tbody" style="--wc:${w.color}"></div>
  <div class="pager noprint">${prev ? `<button class="btn" data-go="${prev.id}">Previous: ${esc(prev.t)}</button>` : "<span></span>"}${next ? `<button class="btn" data-go="${next.id}">Next: ${esc(next.t)}</button>` : `<button class="btn primary" data-boss="${w.id}">${icon("bolt")}${esc(w.name)} boss battle</button>`}</div>`;
  if (editingTopic === t.id) return renderEditor(t);
  if (t.planned) return renderPlanned(t);
  renderTab(t);
}
function renderPlanned(t){
  $("#tbody").innerHTML = `<div class="panel empty" style="margin-top:20px"><span style="font-size:2rem">${t.world.icon}</span><h2 style="margin:10px 0 6px">This topic is empty</h2><p class="muted">Write its key points, flashcards, interview questions and quiz in your own words. Writing it yourself is one of the best ways to remember it.</p><div class="row" style="justify-content:center;margin-top:14px"><button class="btn primary" id="tmanual">${icon("edit")}Write the notes</button></div></div>`;
  $("#tmanual").onclick = () => { editingTopic = t.id; renderPage(); };
}
function renderTab(t){
  const el = $("#tbody"), w = t.world, ts = topicStats(t), rec = S.topics[t.id] || {};
  keyHandler = null; stopTimers();
  if (topicTab === "notes") {
    el.innerHTML = `<div class="tlayout"><div>
      ${t.hook ? `<div class="panel hookbox"><div class="kicker">${icon("brain")}Remember it by</div><p class="hk">${fmt(t.hook)}</p></div>` : ""}
      ${t.sum ? `<p class="lead">${fmt(t.sum)}</p>` : ""}
      <section class="panel section visbox" style="--wc:${w.color}"><div class="kicker">${icon("grid")}See it</div>${visHTML(t)}</section>
      ${t.doc ? lessonHTML(t) : ""}
      <section class="panel section"><div class="shead"><h2>${t.doc ? "Summary: key points" : "Key points"}</h2><label class="switch"><input type="checkbox" id="recallmode" ${recallMode ? "checked" : ""}>Recall mode</label></div>
        ${recallMode ? '<p class="muted small" style="margin:0 0 6px">Say each point from memory, then tap it to check. Retrieval is what makes it stick.</p>' : ""}
        <ol class="points ${recallMode ? "hidden" : ""}">${t.pts.map(p => `<li ${recallMode ? 'tabindex="0" role="button" aria-label="Reveal point"' : ""}><span class="pt">${fmt(p)}</span></li>`).join("")}</ol></section>
      ${t.code && !t.doc ? `<section class="codewrap"><div class="codehead"><span>Example</span><button class="copy">Copy</button></div><pre><code>${hl(t.code)}</code></pre></section>` : ""}
      ${t.traps.length ? `<section class="panel section traps"><h3>Interview traps</h3><ul>${t.traps.map(x => `<li>${fmt(x)}</li>`).join("")}</ul></section>` : ""}
      ${checkpointHTML(t)}
      <section class="panel section"><div class="shead"><h2>Your notes</h2><span class="muted small" id="notesaved">${rec.note ? "Saved" : ""}</span></div>
        <p class="muted small" style="margin:0 0 8px">Write it in your own words or add an example. Explaining it yourself is one of the strongest memory boosters.</p>
        <textarea class="input" id="mynote" placeholder="e.g. In my project I used this when…">${esc(rec.note || "")}</textarea></section>
    </div>
    <aside class="panel pad aside-card"><h3 style="margin-bottom:8px">Your progress</h3>
      <div class="kv"><span>Status</span>${pill(ts.status)}</div>
      <div class="kv"><span>Mastery</span><b>${ts.mastery}%</b></div>
      <div class="kv"><span>Recall today</span><b>${ts.ret == null ? "–" : Math.round(ts.ret * 100) + "%"}</b></div>
      <div class="kv"><span>Strength</span>${meter(ts.avgBox, w.color)}</div>
      ${t.doc ? `<div class="kv"><span>Lesson read</span><b>${((rec.read || []).length)}/${t.doc.length}</b></div>` : ""}
      <div class="kv"><span>Best quiz</span><b>${rec.quiz != null ? rec.quiz + "%" : "–"}</b></div>
      <div class="kv"><span>Arena</span><b>${rec.stars ? "★".repeat(rec.stars) + "☆".repeat(3 - rec.stars) : "–"}</b></div>
      <div style="display:grid;gap:8px;margin-top:14px">${rec.learned ? `<span class="pill strong" style="justify-content:center;padding:.5em">Learned, cards are in your review</span>` : `<button class="btn primary" id="markLearned">Mark as learned, +20 XP</button><button class="btn" id="tocp">${icon("bolt")}Go to checkpoint</button>`}
      ${topicFormats(t).includes("practical") ? `<button class="btn" data-tab="practical">${icon("code")}Enter the arena</button>` : ""}
      ${w.custom ? `<button class="btn" id="editc">${icon("edit")}Edit content</button><button class="btn danger" id="deltopic">${icon("trash")}Delete topic</button>` : ""}</div>
      ${rec.learned || !t.cards.length ? "" : `<p class="muted small" style="margin:10px 0 0">Marking it learned adds its ${t.cards.length} flashcards to your daily review.</p>`}</aside></div>`;
    $("#recallmode").onchange = e => { recallMode = e.target.checked; renderTab(t); };
    runCheckpoint(t);
    if (t.doc) wireLesson(el, t);
    el.querySelectorAll(".points.hidden li").forEach(li => {
      const rv = () => li.classList.toggle("shown");
      li.onclick = rv; li.onkeydown = e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); rv(); } };
    });
    const cp = el.querySelector(".copy:not([data-copy])");
    if (cp) cp.onclick = async e => { try { await navigator.clipboard.writeText(t.code); e.target.textContent = "Copied"; } catch (err) { e.target.textContent = "Select to copy"; } };
    let nt;
    $("#mynote").oninput = e => { clearTimeout(nt); const v = e.target.value; const ns = $("#notesaved"); if (ns) ns.textContent = "Saving…"; nt = setTimeout(() => { (S.topics[t.id] = S.topics[t.id] || {}).note = v; save(); if (ns) ns.textContent = "Saved"; }, 500); };
    const tcp = $("#tocp"); if (tcp) tcp.onclick = () => $("#cp") && $("#cp").scrollIntoView({behavior:"smooth", block:"center"});
    const mk = $("#markLearned");
    if (mk) mk.onclick = () => { (S.topics[t.id] = S.topics[t.id] || {}).learned = true; gainXP(20, "topic learned"); renderPage(); };
    const ec = $("#editc");
    if (ec) ec.onclick = () => { editingTopic = t.id; renderPage(); };
    const dl = $("#deltopic");
    if (dl) dl.onclick = async () => {
      if (!(await confirmBox("Delete this topic?", `“${esc(t.t)}” and its cards will be removed from ${esc(w.name)}.`, "Delete", true))) return;
      w.skill.topics = w.skill.topics.filter(x => x.id !== t.id);
      t.cards.forEach((c, i) => delete S.cards[cardKey(t, i)]); delete S.topics[t.id];
      dropTopic(t.id); saveLib(); save(); reindex(); go(w.id);
    };
  } else if (topicTab === "cheat") {
    el.innerHTML = `<div style="max-width:560px">${cheatCard(t)}</div><button class="btn noprint" onclick="window.print()">${icon("print")}Print</button>`;
  } else if (topicTab === "revision") {
    el.innerHTML = `<div class="sess" id="sess"></div>`;
    cardSession($("#sess"), t.cards.map((c, i) => cardItem(t, i)), {after:topicFormats(t).includes("quiz") ? `<button class="btn primary" data-tab="quiz">Take the quiz</button>` : ""});
  } else if (topicTab === "interview") {
    el.innerHTML = `<div class="sess" id="sess"></div>`;
    interviewSession($("#sess"), t.iq.map(q => ({q:q[0], a:q[1], topic:t.t, color:w.color, tid:t.id})), {});
  } else if (topicTab === "quiz") {
    el.innerHTML = `<div class="sess" id="sess"></div>`;
    quizSession($("#sess"), shuffle(t.quiz.map(q => prepQ(t, q))), {topic:t});
  } else if (topicTab === "practical") {
    el.innerHTML = `<div class="sess" id="sess"></div>`;
    arenaSession($("#sess"), shuffle(t.prac.map(c => Object.assign({topic:t.t, color:w.color}, c))), {topic:t});
  }
}
