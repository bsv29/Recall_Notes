/* ================= flashcard session ================= */
function cardSession(el, queue, opts){
  let i = 0, flipped = false, done = 0;
  const total0 = queue.length;
  function draw(){
    if (i >= queue.length) {
      keyHandler = null;
      el.innerHTML = `<div class="panel result"><div class="big">${done}</div><h2 style="margin:8px 0 6px">Deck cleared</h2><p class="muted">Each card is now scheduled to come back right before you’d forget it.</p><div class="row" style="justify-content:center">${opts.after || ""}</div></div>`;
      renderSide(); return;
    }
    const c = queue[i], st = S.cards[c.id], b = st ? st.box : 0;
    const iv = n => { const d = IV[Math.min(MAXBOX, n)]; return d >= 30 ? Math.round(d / 30) + " mo" : d + "d"; };
    el.innerHTML = `<div class="sbar"><span>Card ${Math.min(i + 1, queue.length)} of ${queue.length}</span>${opts.showTopic ? `<span class="tag" style="--wc:${c.color}"><span class="dot"></span>${esc(c.topic)}</span>` : ""}<span>${st ? "Strength " + st.box + " of " + MAXBOX : "New card"}</span></div>
    <div class="prog"><span style="width:${i / queue.length * 100}%"></span></div>
    <div class="fc" style="--wc:${c.color}" tabindex="0" role="button" aria-label="Flashcard. Press Space to flip.">
      <div class="face front"><span class="side-l">Question</span><p>${fmt(c.q)}</p><span class="tap">Tap or press <kbd>Space</kbd></span></div>
      <div class="face back" aria-hidden="true"><span class="side-l">Answer</span><p>${fmt(c.a)}</p></div></div>
    <div class="grades off" aria-label="How well did you remember?">
      <button class="g again" data-g="again"><b>Again</b><small>today <kbd>1</kbd></small></button>
      <button class="g hard" data-g="hard"><b>Hard</b><small>${iv(Math.max(1, b)) === "0d" ? "1d" : Math.max(1, Math.round(IV[Math.max(1, b)] / 2)) + "d"} <kbd>2</kbd></small></button>
      <button class="g good" data-g="good"><b>Good</b><small>${iv(b + 1)} <kbd>3</kbd></small></button>
      <button class="g easy" data-g="easy"><b>Easy</b><small>${iv(b + 2)} <kbd>4</kbd></small></button></div>`;
    el.querySelector(".fc").onclick = flip;
    el.querySelectorAll("[data-g]").forEach(x => x.onclick = () => grade(x.dataset.g));
  }
  function flip(){
    flipped = !flipped;
    const fc = el.querySelector(".fc");
    fc.classList.toggle("flipped", flipped);
    fc.querySelector(".back").setAttribute("aria-hidden", String(!flipped));
    fc.querySelector(".front").setAttribute("aria-hidden", String(flipped));
    el.querySelector(".grades").classList.toggle("off", !flipped);
  }
  function grade(g){
    if (!flipped) return;
    const c = queue[i];
    applyGrade(c.id, g); done++;
    if (g === "again" && !c.requeued) queue.push(Object.assign({}, c, {requeued:true}));
    i++; flipped = false; draw();
  }
  keyHandler = e => {
    if (e.key === " ") { if (e.target.tagName === "BUTTON") return; e.preventDefault(); flip(); }
    else if (flipped && e.key.length === 1 && "1234".includes(e.key)) grade(["again", "hard", "good", "easy"][+e.key - 1]);
  };
  draw();
}

/* ================= quiz & boss ================= */
function prepQ(t, q){
  const order = shuffle(q[1].map((_, k) => k));
  return {q:q[0], opts:order.map(k => q[1][k]), ans:order.indexOf(q[2]), exp:q[3], topic:t.t, color:t.world.color};
}
const isCodey = o => /[()\[\]{}'"=_@*`]|^-?\d/.test(o);
function quizSession(el, items, opts){
  let i = 0, combo = 0, score = 0, hearts = opts.boss ? 3 : 0, locked = false, xpEarned = 0;
  function draw(){
    if (i >= items.length || (opts.boss && hearts <= 0)) return finish();
    const q = items[i]; locked = false;
    el.innerHTML = `<div class="sbar"><span>Question ${i + 1} of ${items.length}</span>${opts.boss ? `<span class="hearts" aria-label="${hearts} lives left">${"♥".repeat(hearts)}<span class="lost">${"♥".repeat(3 - hearts)}</span></span>` : ""}<span class="combo ${combo > 1 ? "hot" : ""}">Combo ×${Math.max(1, Math.min(combo, 3))}</span></div>
    <div class="prog"><span style="width:${i / items.length * 100}%"></span></div>
    <div class="panel qcard" style="--wc:${q.color}">${opts.boss || !opts.topic ? `<span class="tag"><span class="dot" style="--wc:${q.color}"></span>${esc(q.topic)}</span>` : ""}
      <h2 class="qq">${fmt(q.q)}</h2>
      <div class="opts">${q.opts.map((o, k) => `<button class="opt ${isCodey(o) ? "mono" : ""}" data-k="${k}"><span class="key">${"ABCD"[k]}</span><span>${esc(o)}</span></button>`).join("")}</div>
      <div class="explain" hidden></div></div>`;
    el.querySelectorAll(".opt").forEach(b => b.onclick = () => answer(+b.dataset.k));
  }
  function answer(k){
    if (locked) return; locked = true;
    const q = items[i], ok = k === q.ans;
    el.querySelectorAll(".opt").forEach((b, j) => { b.disabled = true; if (j === q.ans) b.classList.add("right"); else if (j === k) b.classList.add("wrong"); });
    if (ok) { combo++; score++; const g = 10 * Math.min(combo, 3); xpEarned += g; gainXP(g, combo > 1 ? "combo ×" + Math.min(combo, 3) : "correct"); }
    else { combo = 0; if (opts.boss) hearts--; }
    const last = i + 1 >= items.length || (opts.boss && hearts <= 0);
    const ex = el.querySelector(".explain");
    ex.hidden = false;
    ex.innerHTML = `<p><strong style="color:var(${ok ? "--good" : "--bad"})">${ok ? "Correct." : "Not quite."}</strong> ${fmt(q.exp)}</p><button class="btn primary" id="qnext">${last ? "See results" : "Next question"}</button>`;
    const nb = $("#qnext"); nb.onclick = () => { i++; draw(); }; nb.focus();
  }
  function finish(){
    keyHandler = null;
    const pct = Math.round(score / items.length * 100);
    let title, msg;
    if (opts.boss) {
      const won = hearts > 0;
      title = won ? "Boss defeated" : "Out of lives";
      msg = won ? `${score} of ${items.length} correct with ${hearts} ${hearts === 1 ? "life" : "lives"} to spare.` : `${score} correct before your lives ran out. Revisit the topics you missed, then try again.`;
      if (won) { S.bosses[opts.world.id] = true; gainXP(100, "boss defeated"); }
    } else if (!opts.topic) {
      title = pct === 100 ? "Perfect run" : pct >= 50 ? "Nice work" : "Keep practising";
      msg = `${pct}% correct across ${new Set(items.map(x => x.topic)).size} topics.`;
      if (pct === 100 && items.length >= 5) gainXP(30, "perfect run");
    } else {
      const rec = S.topics[opts.topic.id] = S.topics[opts.topic.id] || {};
      rec.quiz = Math.max(rec.quiz || 0, pct);
      if (pct === 100) { S.flawless = true; gainXP(30, "perfect quiz"); }
      title = pct === 100 ? "Perfect run" : pct >= 50 ? "Nice work" : "Keep practising";
      msg = `Your best score on this topic is ${rec.quiz}%.`;
      save(); checkBadges();
    }
    el.innerHTML = `<div class="panel result"><div class="big">${score}/${items.length}</div><h2 style="margin:8px 0 6px">${title}</h2><p class="muted">${msg}<br>+${xpEarned} XP from answers</p>
      <div class="row" style="justify-content:center"><button class="btn primary" id="retry">Try again</button>${opts.boss ? `<button class="btn" data-go="${opts.world.id}">Back to ${esc(opts.world.name)}</button>` : opts.topic ? `<button class="btn" data-tab="revision">Review flashcards</button>` : `<button class="btn" data-go="study">Study modes</button>`}</div></div>`;
    $("#retry").onclick = () => opts.boss ? startBoss(opts.world) : opts.topic ? renderTab(opts.topic) : opts.again();
    renderSide();
  }
  keyHandler = e => {
    if (locked || e.key.length !== 1) return;
    const k = "abcd1234".indexOf(e.key.toLowerCase());
    if (k >= 0 && k % 4 < items[i].opts.length) answer(k % 4);
  };
  draw();
}
function startBoss(w){
  route = w.id;
  const pool = [];
  w.topics.forEach(t => (t.quiz || []).forEach(q => pool.push(prepQ(t, q))));
  const n = Math.min(8, pool.length);
  $("#ttl").textContent = w.name + " boss battle"; stopTimers(); keyHandler = null;
  $("#page").innerHTML = `${crumbs([`<button data-go="${w.id}">${esc(w.name)}</button>`, "<span>Boss battle</span>"])}
  <div class="phead"><div><h1>${w.icon} ${esc(w.name)} boss battle</h1><p>${n} mixed questions from every ${esc(w.name)} topic. Three lives; each wrong answer costs one. Win for +100 XP.</p></div></div>
  <div class="sess" id="sess"></div>`;
  quizSession($("#sess"), shuffle(pool).slice(0, n), {boss:true, world:w});
  window.scrollTo(0, 0);
}

/* ================= review ================= */
function renderReview(P){
  const q = reviewQueue(reviewMode);
  const catchup = reviewMode === "catchup";
  P.innerHTML = `<div class="phead"><div><h1>${catchup ? "Catch-up review" : "Daily review"}</h1><p>${catchup ? "Your weakest cards first, the ones closest to being forgotten." : `Due cards from every library, plus up to ${S.prefs.newLimit} new cards a day from topics you’ve learned.`} Rate honestly: the schedule only works if “Good” means you really remembered.</p></div>
    ${catchup ? `<button class="btn" id="dailybtn">Switch to daily review</button>` : ""}</div><div class="sess" id="sess"></div>`;
  if ($("#dailybtn")) $("#dailybtn").onclick = () => go("review");
  const el = $("#sess");
  if (!q.length) {
    el.innerHTML = `<div class="panel empty"><span style="font-size:2rem">🎉</span><h2 style="margin:10px 0 6px">All caught up</h2><p class="muted">${learnedCount() ? (newLeftToday() ? "No cards are due. Learn another topic to add new cards, or try a boss battle." : "You’ve hit today’s new-card limit. Come back tomorrow, or raise the limit in Settings.") : "Learn a topic first. Its flashcards join this queue automatically."}</p><button class="btn primary" data-go="library">Open library</button></div>`;
    return;
  }
  cardSession(el, q, {showTopic:true, after:`<button class="btn primary" data-go="dashboard">Back to dashboard</button>`});
}

/* ================= cheat sheets ================= */
const CSW = () => WORLDS.filter(w => w.formats.includes("cheat") && w.topics.some(t => !t.planned));
function renderCheats(P){
  const w = CSW().find(x => x.id === csWorld) || CSW()[0];
  const list = w.topics.filter(t => !t.planned && t.pts.length && (!csLearnedOnly || (S.topics[t.id] && S.topics[t.id].learned)));
  P.innerHTML = `<div class="phead"><div><h1>Cheat sheets</h1><p>Every hook, key point and trap on one page. Skim it before an interview, or print it.</p></div>
    <div class="row noprint"><label class="switch"><input type="checkbox" id="cslearned" ${csLearnedOnly ? "checked" : ""}>Only learned topics</label><button class="btn" onclick="window.print()">${icon("print")}Print</button></div></div>
  <div class="seg noprint" style="margin-bottom:20px" role="tablist">${CSW().map(x => `<button class="${x.id === w.id ? "on" : ""}" data-csw="${x.id}">${esc(x.name)}</button>`).join("")}</div>
  ${list.length ? `<div class="sheet">${list.map(cheatCard).join("")}</div>` : `<div class="panel empty"><p class="muted">${w.topics.length ? "No learned topics here yet. Turn off the filter to see the full sheet." : "No notes in this section yet."}</p></div>`}`;
  P.querySelectorAll("[data-csw]").forEach(b => b.onclick = () => { csWorld = b.dataset.csw; renderCheats(P); });
  $("#cslearned").onchange = e => { csLearnedOnly = e.target.checked; renderCheats(P); };
}

/* ================= progress ================= */
function renderProgress(P){
  const l = level(S.xp), a = lvlStart(l), b = lvlEnd(l);
  const cardsSeen = Object.keys(S.cards).length, longTerm = Object.values(S.cards).filter(c => c.box >= 5).length;
  const rows = ALL.map(t => ({t, s:topicStats(t)})).filter(x => x.s.learned || x.s.seen).sort((x, y) => (x.s.ret == null ? 2 : x.s.ret) - (y.s.ret == null ? 2 : y.s.ret));
  P.innerHTML = `<div class="phead"><div><h1>Progress</h1><p>Level ${l}, ${rank(l)}. ${S.xp - a} of ${b - a} XP to the next level.</p></div></div>
  <div class="panel pad" style="margin-bottom:16px"><div class="bar" style="height:10px"><span style="width:${(S.xp - a) / (b - a) * 100}%"></span></div></div>
  <div class="grid g3" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr))">
    ${[[S.xp, "total XP"], [currentStreak(), "day streak"], [S.best || 0, "best streak"], [learnedCount(), "topics learned"], [S.reviews, "cards reviewed"], [longTerm, "cards in long-term memory"]].map(x => `<div class="panel pad"><div class="big" style="font-size:1.8rem">${x[0]}</div><div class="muted small">${x[1]}</div></div>`).join("")}
  </div>
  <h2 style="margin:28px 0 12px">Badges</h2>
  <div class="badges">${BADGES.map(bd => `<div class="badge ${S.badges.includes(bd.id) ? "on" : ""}"><span class="bi">${bd.icon}</span><div><b>${bd.name}</b><small>${bd.how}</small></div></div>`).join("")}</div>
  <h2 style="margin:28px 0 12px">Topic memory</h2>
  ${rows.length ? `<div class="panel tbl-wrap"><table class="table"><thead><tr><th>Topic</th><th>Library</th><th>Status</th><th>Strength</th><th>Recall today</th></tr></thead><tbody>
    ${rows.map(x => `<tr data-go="${x.t.id}"><td class="tt">${esc(x.t.t)}</td><td><span class="tag"><span class="dot" style="--wc:${x.t.world.color}"></span>${esc(x.t.world.name)}</span></td><td>${pill(x.s.status)}</td><td>${meter(x.s.avgBox, x.t.world.color)}</td><td><b>${x.s.ret == null ? "–" : Math.round(x.s.ret * 100) + "%"}</b></td></tr>`).join("")}
  </tbody></table></div>` : `<div class="panel empty"><p class="muted">Learn a topic and review its cards to see your memory here.</p></div>`}`;
}

/* ================= settings ================= */
function renderSettings(P){
  const p = S.prefs;
  const seg = (key, vals) => `<div class="seg" data-pref="${key}">${vals.map(v => `<button class="${String(p[key]) === String(v[0]) ? "on" : ""}" data-v="${v[0]}">${v[1]}</button>`).join("")}</div>`;
  const accents = [["lagoon", "#0E8580"], ["ember", "#C94A22"], ["iris", "#5B45D6"], ["gold", "#9A6B00"]];
  P.innerHTML = `<div class="phead"><div><h1>Settings</h1><p>Appearance, study plan and account.</p></div></div>
  <section class="panel" style="margin-bottom:16px">
    <div class="set"><div><h3>Theme</h3><p>System follows your device.</p></div><div>${seg("theme", [["system", "System"], ["light", "Light"], ["dark", "Dark"]])}</div></div>
    <div class="set"><div><h3>Accent color</h3><p>Used for buttons, progress and highlights.</p></div><div class="swatches">${accents.map(a => `<button class="sw ${p.accent === a[0] ? "on" : ""}" style="--c:${a[1]}" data-accent="${a[0]}" aria-label="${a[0]}"></button>`).join("")}</div></div>
    <div class="set"><div><h3>Text size</h3></div><div>${seg("size", [["s", "Small"], ["m", "Medium"], ["l", "Large"]])}</div></div>
    <div class="set"><div><h3>Animations</h3><p>Card flips and level-up effects.</p></div><div><label class="switch"><input type="checkbox" id="motion" ${p.motion ? "checked" : ""}>${p.motion ? "On" : "Off"}</label></div></div>
  </section>
  <section class="panel" style="margin-bottom:16px">
    <div class="set"><div><h3>Daily goal</h3><p>Cards to review each day.</p></div><div>${seg("goal", [[10, "10"], [20, "20"], [40, "40"], [60, "60"]])}</div></div>
    <div class="set"><div><h3>New cards per day</h3><p>Fewer new cards keeps reviews manageable later.</p></div><div>${seg("newLimit", [[5, "5"], [10, "10"], [20, "20"], [40, "40"]])}</div></div>
    <div class="set"><div><h3>Focus areas</h3><p>Shape the “Up next” list on your dashboard.</p></div><div class="chips" style="margin:0">${BUILTIN.map(w => `<button class="chip ${S.focus.includes(w.id) ? "on" : ""}" style="--wc:${w.color}" data-fw="${w.id}"><span class="dot"></span>${w.name}</button>`).join("")}</div></div>
  </section>
  <section class="panel" style="margin-bottom:16px">
    <div class="set"><div><h3>Account</h3><p>Your name and sign-in details. Progress syncs to the Recall server.</p></div><div>
      <div class="grid g2" style="gap:12px"><div><label class="lbl" for="aname">Name</label><input class="input" id="aname" value="${esc(ME.name)}"></div><div><label class="lbl">Email</label><input class="input" value="${esc(ME.email)}" disabled></div></div>
      <div class="row" style="margin-top:12px"><button class="btn" id="savename">Save name</button><button class="btn" id="chpw">Change password</button><span class="spacer"></span><button class="btn" id="so">${icon("out")}Sign out</button></div></div></div>
  </section>
  <section class="panel" style="margin-bottom:16px">
    <div class="set"><div><h3>Backup</h3><p>Everything already syncs to the server. A backup file is an extra copy you control.</p></div><div>
      <p class="small" style="margin:0 0 10px">${backupAge() == null ? "No backup yet." : backupAge() === 0 ? "Last backup: today." : `Last backup: ${backupAge()} day${backupAge() === 1 ? "" : "s"} ago.`}</p>
      <div class="row"><button class="btn primary" id="exp">Download backup</button><label class="btn" for="impfile">Restore from file</label><input type="file" id="impfile" accept=".json,application/json" hidden></div></div></div>
  </section>
  <section class="panel" style="margin-bottom:16px">
    <div class="set"><div><h3>Reset progress</h3><p>Clears XP, streaks, card schedules and quiz scores. Your skills and notes stay.</p></div><div><button class="btn danger" id="reset">Reset progress</button></div></div>
    <div class="set"><div><h3>Delete account</h3><p>Removes this account and all its data from this browser.</p></div><div><button class="btn danger" id="delacct">Delete account</button></div></div>
    <div class="set"><div><h3>Your courses</h3><p>Rename, add topics, change sections or delete a course you added.</p></div><div class="row">${LIB.skills.length ? LIB.skills.map(sk => `<button class="chip" data-edit="${sk.id}">${sk.icon} ${esc(sk.name)}</button>`).join("") : `<button class="btn" data-go="newskill">${icon("plus")}Add a course</button>`}</div></div>
  </section>`;
  P.querySelectorAll("[data-pref]").forEach(g => g.querySelectorAll("button").forEach(b => b.onclick = () => {
    const k = g.dataset.pref; p[k] = ["goal", "newLimit"].includes(k) ? +b.dataset.v : b.dataset.v; save(); applyPrefs(); renderSettings(P); renderSide();
  }));
  P.querySelectorAll("[data-accent]").forEach(b => b.onclick = () => { p.accent = b.dataset.accent; save(); applyPrefs(); renderSettings(P); });
  P.querySelectorAll("[data-fw]").forEach(b => b.onclick = () => { const id = b.dataset.fw; S.focus = S.focus.includes(id) ? S.focus.filter(x => x !== id) : S.focus.concat(id); if (!S.focus.length) S.focus = [id]; save(); renderSettings(P); });
  $("#motion").onchange = e => { p.motion = e.target.checked; save(); applyPrefs(); renderSettings(P); };
  $("#so").onclick = async () => { if (await confirmBox("Sign out?", "Your progress is saved to your account.", "Sign out")) { signOutLocal(); render(); } };
  $("#savename").onclick = async () => { const v = $("#aname").value.trim(); if (!v) return toast("Enter a name"); try { await updateAccount({name:v}); renderSide(); toast("Name saved"); } catch (e) { toast(e.message); } };
  $("#chpw").onclick = () => modal(`<h2>Change password</h2><label class="lbl" for="opw">Current password</label><input class="input" id="opw" type="password" data-focus><label class="lbl" for="npw" style="margin-top:10px">New password</label><input class="input" id="npw" type="password"><p class="formerr" id="pwerr" hidden></p><div class="row"><button class="btn" data-x>Cancel</button><button class="btn primary" id="pwok">Change password</button></div>`, (m, close) => {
    m.querySelector("[data-x]").onclick = close;
    m.querySelector("#pwok").onclick = async () => {
      const e = m.querySelector("#pwerr"), np = m.querySelector("#npw").value;
      if (np.length < 8) { e.hidden = false; e.textContent = "Use at least 8 characters."; return; }
      try { await changePassword(m.querySelector("#opw").value, np); close(); toast("Password changed"); }
      catch (err) { e.hidden = false; e.textContent = err.message; }
    };
  });
  $("#exp").onclick = () => { exportBackup(); renderSettings(P); };
  $("#impfile").onchange = async e => {
    const file = e.target.files[0]; if (!file) return;
    if (!(await confirmBox("Restore this backup?", "It replaces the skills, notes and progress in this account with the ones in the file.", "Restore"))) return;
    importBackup(file, ok => { toast(ok ? "Backup restored" : "That file isn’t a Recall backup", ok); renderPage(); });
  };
  $("#delacct").onclick = async () => {
    if (!(await confirmBox("Delete your account?", "Your account, courses, notes and progress will be permanently deleted from the server. Download a backup first if you might want them later.", "Delete account", true))) return;
    try { await deleteAccount(); localStorage.removeItem(cacheKey()); signOutLocal(); render(); toast("Account deleted"); }
    catch (e) { toast(e.message); }
  };
  $("#reset").onclick = async () => {
    if (!(await confirmBox("Reset all progress?", "XP, streaks, badges, card schedules and quiz scores will be cleared. This can’t be undone.", "Reset progress", true))) return;
    const keep = {prefs:S.prefs, focus:S.focus, onboarded:true, lastBackup:S.lastBackup};
    S = Object.assign(freshState(), keep); save(); toast("Progress reset"); renderPage();
  };
}

/* ================= search ================= */
function setupSearch(){
  const q = $("#q"), box = $("#results");
  let sel = -1, hits = [];
  function run(){
    const s = q.value.trim().toLowerCase();
    if (s.length < 2) { box.hidden = true; return; }
    hits = [];
    ALL.forEach(t => {
      if (t.planned && !t.t.toLowerCase().includes(s)) return;
      const hay = (t.t + " " + t.hook).toLowerCase();
      if (hay.includes(s)) hits.push({t, score:t.t.toLowerCase().includes(s) ? 0 : 1, sub:t.planned ? "Empty topic" : plain(t.hook)});
      else {
        const p = t.pts.find(x => x.toLowerCase().includes(s)) || (t.cards.find(c => c[0].toLowerCase().includes(s)) || [])[0];
        if (p) hits.push({t, score:2, sub:plain(p)});
      }
    });
    hits.sort((a, b) => a.score - b.score); hits = hits.slice(0, 8); sel = -1;
    box.innerHTML = hits.length ? hits.map((h, i) => `<button data-hit="${i}"><span class="rt"><span class="dot" style="--wc:${h.t.world.color}"></span>${esc(h.t.t)}</span><span class="rs">${esc(h.t.world.name)}: ${esc(h.sub.replace(/`/g, "").slice(0, 90))}</span></button>`).join("") : `<p class="muted small" style="padding:8px 10px;margin:0">No matches for “${esc(q.value)}”.</p>`;
    box.hidden = false;
    box.querySelectorAll("[data-hit]").forEach(b => b.onmousedown = e => { e.preventDefault(); pick(+b.dataset.hit); });
  }
  function pick(i){ const h = hits[i]; if (!h) return; q.value = ""; box.hidden = true; q.blur(); go(h.t.id); }
  q.oninput = run;
  q.onfocus = run;
  q.onblur = () => setTimeout(() => box.hidden = true, 120);
  q.onkeydown = e => {
    if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); sel = Math.max(0, Math.min(hits.length - 1, sel + (e.key === "ArrowDown" ? 1 : -1))); box.querySelectorAll("[data-hit]").forEach((b, i) => b.classList.toggle("sel", i === sel)); }
    else if (e.key === "Enter") pick(sel < 0 ? 0 : sel);
    else if (e.key === "Escape") { q.value = ""; box.hidden = true; q.blur(); }
  };
}

