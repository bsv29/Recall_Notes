/* ================= timers ================= */
let tickId = null;
function stopTimers(){ if (tickId) { clearInterval(tickId); tickId = null; } }

/* ================= practical arena ================= */
const normAns = s => String(s).trim().replace(/[“”"]/g, "'").replace(/\s+/g, "").replace(/;$/, "").toLowerCase();
const PTYPE = {predict:"Predict the output", blank:"Fill in the blank", bug:"Find the bug", order:"Put the lines in order"};
function arenaSession(el, items, opts){
  items = items.slice(0, opts.max || 8);
  if (!items.length) { el.innerHTML = `<div class="panel empty"><p class="muted">No practical challenges here yet.</p></div>`; return; }
  let i = 0, hearts = 3, combo = 0, xp = 0, correct = 0, locked = false, left = 0, startT = 0, hintUsed = false;
  let order = null, picked = [];
  const limit = c => c.type === "order" ? 90 : c.type === "bug" ? 60 : 75;
  function hud(){
    return `<div class="arena-hud"><span class="hearts" aria-label="${hearts} lives">${"♥".repeat(hearts)}<span class="lost">${"♥".repeat(3 - hearts)}</span></span>
      <span class="ah-mid">Challenge ${i + 1} of ${items.length}</span>
      <span class="combo ${combo > 1 ? "hot" : ""}">${icon("fire")}×${Math.max(1, Math.min(combo, 3))}</span><span class="xp-now">${xp} XP</span></div>
      <div class="timer"><span id="tbar"></span></div>`;
  }
  function draw(){
    stopTimers();
    if (i >= items.length || hearts <= 0) return finish();
    const c = items[i]; locked = false; hintUsed = false; picked = [];
    let body = "";
    if (c.type === "predict" || c.type === "blank") {
      body = `<pre class="arena-code"><code>${hl(c.code)}</code></pre>
        <div class="answer-row"><input class="input mono" id="ans" autocomplete="off" spellcheck="false" placeholder="${c.type === "predict" ? "Type the exact output" : "Type the missing code"}" aria-label="Your answer"><button class="btn primary" id="sub">Submit</button></div>
        <div class="row" style="margin-top:10px"><button class="link" id="hint">Hint (−5 XP)</button><span class="spacer"></span><button class="link" id="skip" style="color:var(--muted)">Skip</button></div>`;
    } else if (c.type === "bug") {
      body = `<p class="muted small" style="margin:0 0 8px">Tap the line that’s wrong.</p><div class="lines">${c.lines.map((l, k) => `<button class="cl" data-l="${k}"><span class="ln">${k + 1}</span><code>${hl(l) || " "}</code></button>`).join("")}</div>`;
    } else {
      order = shuffle(c.lines.map((l, k) => k));
      if (order.every((v, k) => v === k) && order.length > 1) order.reverse();
      body = `<p class="muted small" style="margin:0 0 8px">Tap the lines in the order they should run. Tap a placed line to send it back.</p>
        <div class="lines built" id="built"></div><div class="lines pool" id="pool"></div>
        <div class="row" style="margin-top:12px"><button class="btn primary" id="chk" disabled>Check order</button></div>`;
    }
    el.innerHTML = `${hud()}<div class="panel qcard arena" style="--wc:${c.color}"><div class="row" style="justify-content:space-between"><span class="ptype">${icon("code")}${PTYPE[c.type]}</span><span class="tag"><span class="dot" style="--wc:${c.color}"></span>${esc(c.topic)}</span></div>${body}<div class="explain" hidden></div></div>`;
    if (c.type === "order") drawOrder(c);
    el.querySelectorAll(".cl[data-l]").forEach(b => b.onclick = () => judge(+b.dataset.l === c.bug, b));
    const inp = $("#ans");
    if (inp) {
      inp.focus();
      inp.onkeydown = e => { if (e.key === "Enter") { e.preventDefault(); submitText(); } };
      $("#sub").onclick = submitText;
      $("#hint").onclick = () => { if (hintUsed) return; hintUsed = true; const a = String(c.answer[0]); $("#hint").outerHTML = `<span class="muted small">Starts with <code>${esc(a.slice(0, Math.max(1, Math.ceil(a.length / 4))))}</code>, ${a.length} characters</span>`; };
      $("#skip").onclick = () => judge(false);
    }
    left = limit(c); startT = Date.now();
    tickId = setInterval(() => {
      const el2 = $("#tbar"); if (!el2) return stopTimers();
      const rem = Math.max(0, left - (Date.now() - startT) / 1000);
      el2.style.width = (rem / left * 100) + "%";
      el2.classList.toggle("low", rem < 15);
      if (rem <= 0) { stopTimers(); judge(false, null, true); }
    }, 200);
  }
  function drawOrder(c){
    const B = $("#built"), Pn = $("#pool");
    B.innerHTML = picked.length ? picked.map((k, j) => `<button class="cl" data-b="${j}"><span class="ln">${j + 1}</span><code>${hl(c.lines[k])}</code></button>`).join("") : `<p class="muted small" style="margin:6px 4px">Your program builds here.</p>`;
    Pn.innerHTML = order.filter(k => !picked.includes(k)).map(k => `<button class="cl" data-p="${k}"><code>${hl(c.lines[k])}</code></button>`).join("");
    B.querySelectorAll("[data-b]").forEach(b => b.onclick = () => { if (locked) return; picked.splice(+b.dataset.b, 1); drawOrder(c); });
    Pn.querySelectorAll("[data-p]").forEach(b => b.onclick = () => { if (locked) return; picked.push(+b.dataset.p); drawOrder(c); });
    $("#chk").disabled = picked.length !== c.lines.length;
    $("#chk").onclick = () => judge(picked.every((k, j) => c.lines[k] === c.lines[j]));
  }
  function submitText(){
    const v = $("#ans").value; if (!v.trim()) return;
    judge(items[i].answer.some(a => normAns(a) === normAns(v)));
  }
  function judge(ok, btn, timeout){
    if (locked) return; locked = true; stopTimers();
    const c = items[i];
    const secs = (Date.now() - startT) / 1000;
    if (c.type === "bug") el.querySelectorAll(".cl[data-l]").forEach(b => { b.disabled = true; if (+b.dataset.l === c.bug) b.classList.add("right"); else if (b === btn) b.classList.add("wrong"); });
    if ($("#ans")) $("#ans").disabled = true;
    let gain = 0;
    if (ok) {
      combo++; correct++;
      const speed = Math.max(0, Math.round(10 * (1 - secs / limit(c))));
      gain = Math.max(5, (15 + speed - (hintUsed ? 5 : 0)) * Math.min(combo, 3));
      xp += gain; gainXP(gain, combo > 1 ? "combo ×" + Math.min(combo, 3) : "solved");
    } else { combo = 0; hearts--; }
    const reveal = c.type === "bug" ? `Fix: <code>${esc(c.fix)}</code>` : c.type === "order" ? `<pre class="arena-code small"><code>${hl(c.lines.join("\n"))}</code></pre>` : `Answer: <code>${esc(c.answer[0])}</code>`;
    const last = i + 1 >= items.length || hearts <= 0;
    const ex = el.querySelector(".explain"); ex.hidden = false;
    ex.innerHTML = `<p><strong style="color:var(${ok ? "--good" : "--bad"})">${ok ? `Solved in ${Math.round(secs)}s.` : timeout ? "Time’s up." : "Not quite."}</strong> ${ok ? "" : reveal} ${fmt(c.explain || "")}</p><button class="btn primary" id="anext">${last ? "See results" : "Next challenge"}</button>`;
    const nb = $("#anext"); nb.onclick = () => { i++; draw(); }; nb.focus();
  }
  function finish(){
    stopTimers(); keyHandler = null;
    const pct = correct / items.length, stars = hearts <= 0 ? (correct ? 1 : 0) : pct >= .9 ? 3 : pct >= .6 ? 2 : correct ? 1 : 0;
    S.arena.played++; S.arena.best = Math.max(S.arena.best, xp);
    if (opts.topic) { const rec = S.topics[opts.topic.id] = S.topics[opts.topic.id] || {}; rec.stars = Math.max(rec.stars || 0, stars); }
    if (stars === 3) gainXP(40, "three stars"); else { save(); checkBadges(); }
    el.innerHTML = `<div class="panel result arena-end"><div class="stars" aria-label="${stars} of 3 stars">${[0, 1, 2].map(k => `<span class="${k < stars ? "on" : ""}">★</span>`).join("")}</div>
      <h2 style="margin:6px 0">${hearts <= 0 ? "Out of lives" : stars === 3 ? "Flawless run" : stars === 2 ? "Strong run" : "Run complete"}</h2>
      <p class="muted">${correct} of ${items.length} solved, ${xp} XP earned. Best run: ${S.arena.best} XP.</p>
      <div class="row" style="justify-content:center"><button class="btn primary" id="again">Play again</button>${opts.topic ? `<button class="btn" data-tab="notes">Back to notes</button>` : `<button class="btn" data-go="study">Study modes</button>`}</div></div>`;
    $("#again").onclick = () => opts.topic ? renderTab(opts.topic) : opts.again();
    renderSide();
  }
  keyHandler = e => {
    const c = items[i]; if (!c || locked) return;
    if (c.type === "bug" && /^[1-9]$/.test(e.key) && +e.key <= c.lines.length) { const b = el.querySelector(`.cl[data-l="${+e.key - 1}"]`); judge(+e.key - 1 === c.bug, b); }
  };
  draw();
}

/* ================= mock interview ================= */
function interviewSession(el, items, opts){
  items = shuffle(items).slice(0, opts.max || 8);
  if (!items.length) { el.innerHTML = `<div class="panel empty"><p class="muted">No interview questions here yet.</p></div>`; return; }
  let i = 0, nailed = 0, partly = 0, xp = 0, shown = false, t0 = 0;
  function draw(){
    stopTimers();
    if (i >= items.length) return finish();
    const q = items[i]; shown = false; t0 = Date.now();
    el.innerHTML = `<div class="sbar"><span>Question ${i + 1} of ${items.length}</span><span class="tag"><span class="dot" style="--wc:${q.color}"></span>${esc(q.topic)}</span><span class="clock" id="clock">0:00</span></div>
      <div class="prog"><span style="width:${i / items.length * 100}%"></span></div>
      <div class="panel qcard interview" style="--wc:${q.color}"><div class="iv-who">${icon("mic")}Interviewer</div><h2 class="qq">${fmt(q.q)}</h2>
        <label class="lbl" for="myans">Your answer</label>
        <textarea class="input" id="myans" rows="4" placeholder="Answer as you would out loud. Aim for 2–4 sentences with one example."></textarea>
        <div class="row" style="margin-top:12px"><button class="btn primary" id="reveal">Show model answer</button><span class="muted small">or press <kbd>Ctrl</kbd>+<kbd>Enter</kbd></span></div>
        <div id="model" hidden></div></div>`;
    $("#myans").focus();
    $("#myans").onkeydown = e => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); reveal(); } };
    $("#reveal").onclick = reveal;
    tickId = setInterval(() => { const c = $("#clock"); if (!c) return stopTimers(); const s = Math.floor((Date.now() - t0) / 1000); c.textContent = Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); c.classList.toggle("long", s > 90); }, 500);
  }
  function reveal(){
    if (shown) return; shown = true; stopTimers();
    const q = items[i];
    $("#reveal").parentElement.hidden = true;
    const m = $("#model"); m.hidden = false;
    m.innerHTML = `<div class="model"><div class="kicker">Model answer</div><p>${fmt(q.a)}</p></div>
      <p class="muted small" style="margin:12px 0 8px">How close were you?</p>
      <div class="grades"><button class="g again" data-r="0"><b>Missed it</b><small>+2 XP</small></button><button class="g hard" data-r="1"><b>Partly</b><small>+5 XP</small></button><button class="g good" data-r="2" style="grid-column:span 2"><b>Nailed it</b><small>+10 XP</small></button></div>`;
    m.querySelectorAll("[data-r]").forEach(b => b.onclick = () => rate(+b.dataset.r));
  }
  function rate(r){
    const g = [2, 5, 10][r]; xp += g;
    if (r === 2) { nailed++; S.nailed = (S.nailed || 0) + 1; } else if (r === 1) partly++;
    const tid = items[i].tid; if (tid) { const rec = S.topics[tid] = S.topics[tid] || {}; rec.iv = (rec.iv || 0) + (r === 2 ? 1 : 0); }
    gainXP(g, r === 2 ? "nailed it" : "answer reviewed", r !== 2);
    i++; draw();
  }
  function finish(){
    stopTimers(); keyHandler = null;
    const conf = Math.round((nailed + partly * .5) / items.length * 100);
    el.innerHTML = `<div class="panel result"><div class="big">${conf}%</div><h2 style="margin:8px 0 6px">Interview confidence</h2><p class="muted">${nailed} nailed, ${partly} partly, ${items.length - nailed - partly} missed. +${xp} XP</p>
      <div class="row" style="justify-content:center"><button class="btn primary" id="again">Another round</button>${opts.again ? `<button class="btn" data-go="study">Study modes</button>` : `<button class="btn" data-tab="notes">Back to notes</button>`}</div></div>`;
    $("#again").onclick = () => opts.again ? opts.again() : renderTab(BYID[route]);
    renderSide();
  }
  keyHandler = e => { if (shown && "123".includes(e.key) && e.key.length === 1) rate(+e.key - 1); };
  draw();
}

/* ================= study modes ================= */
let study = {mode:null, world:null, scope:"all", picks:[]};
function studyTopics(w){
  const base = w.topics.filter(t => !t.planned && topicFormats(t).includes(study.mode));
  if (study.scope === "learned") return base.filter(t => S.topics[t.id] && S.topics[t.id].learned);
  if (study.scope === "pick") return base.filter(t => study.picks.includes(t.id));
  return base;
}
function renderStudy(P){
  const mode = study.mode;
  const worlds = mode ? WORLDS.filter(w => w.formats.includes(mode) && w.topics.some(t => !t.planned && topicFormats(t).includes(mode))) : [];
  if (mode && (!study.world || !worlds.some(w => w.id === study.world))) study.world = worlds[0] ? worlds[0].id : null;
  const w = WORLDS.find(x => x.id === study.world);
  const avail = w ? w.topics.filter(t => !t.planned && topicFormats(t).includes(mode)) : [];
  const chosen = w ? studyTopics(w) : [];
  const unit = {notes:"topics", cheat:"cards", revision:"flashcards", interview:"questions", quiz:"questions", practical:"challenges"}[mode];
  const n = !w ? 0 : mode === "revision" ? chosen.reduce((a, t) => a + t.cards.length, 0) : mode === "interview" ? Math.min(10, chosen.reduce((a, t) => a + t.iq.length, 0)) : mode === "quiz" ? Math.min(15, chosen.reduce((a, t) => a + t.quiz.length, 0)) : mode === "practical" ? Math.min(8, chosen.reduce((a, t) => a + t.prac.length, 0)) : chosen.length;
  P.innerHTML = `<div class="phead"><div><h1>Study modes</h1><p>Choose how you want to study, what to study, and go. Mixing topics in one session is the fastest way to make knowledge stick.</p></div></div>
  <h3 class="step-h"><span>1</span>How do you want to study?</h3>
  <div class="modegrid">${FORMATS.map(f => `<button class="modecard ${mode === f.id ? "on" : ""}" data-pickmode="${f.id}">${icon(f.icon)}<b>${f.name}</b><small>${f.desc}</small></button>`).join("")}</div>
  ${mode ? `<h3 class="step-h"><span>2</span>Which skill?</h3>
    ${worlds.length ? `<div class="chips">${worlds.map(x => `<button class="chip ${x.id === study.world ? "on" : ""}" style="--wc:${x.color}" data-pickw="${x.id}"><span class="dot"></span>${esc(x.name)}</button>`).join("")}</div>` : `<p class="muted">No skills have ${FMT[mode].name.toLowerCase()} content yet.</p>`}` : ""}
  ${w ? `<h3 class="step-h"><span>3</span>Which topics?</h3>
    <div class="seg" style="margin-bottom:12px">${[["all", "All " + avail.length], ["learned", "Learned only"], ["pick", "Choose"]].map(x => `<button class="${study.scope === x[0] ? "on" : ""}" data-scope="${x[0]}">${x[1]}</button>`).join("")}</div>
    ${study.scope === "pick" ? `<div class="chips">${avail.map(t => `<button class="chip ${study.picks.includes(t.id) ? "on" : ""}" style="--wc:${w.color}" data-pickt="${t.id}">${esc(t.t)}</button>`).join("")}</div>` : ""}
    <div class="startbar panel"><div><b>${n} ${unit}</b><span class="muted small"> from ${chosen.length} topic${chosen.length === 1 ? "" : "s"} in ${esc(w.name)}</span></div><button class="btn primary lg" id="go" ${n ? "" : "disabled"}>Start ${FMT[mode].name.toLowerCase()}</button></div>` : ""}
  <div id="studyout"></div>`;
  P.querySelectorAll("[data-pickmode]").forEach(b => b.onclick = () => { study.mode = b.dataset.pickmode; renderStudy(P); });
  P.querySelectorAll("[data-pickw]").forEach(b => b.onclick = () => { study.world = b.dataset.pickw; study.picks = []; renderStudy(P); });
  P.querySelectorAll("[data-scope]").forEach(b => b.onclick = () => { study.scope = b.dataset.scope; renderStudy(P); });
  P.querySelectorAll("[data-pickt]").forEach(b => b.onclick = () => { const id = b.dataset.pickt; study.picks = study.picks.includes(id) ? study.picks.filter(x => x !== id) : study.picks.concat(id); renderStudy(P); });
  if ($("#go")) $("#go").onclick = () => startStudy(P, w, chosen);
}
function startStudy(P, w, list){
  const mode = study.mode, again = () => startStudy(P, w, list);
  stopTimers(); keyHandler = null;
  const head = `${crumbs([`<button data-go="study">Study modes</button>`, `<span>${FMT[mode].name}</span>`])}<div class="phead"><div><h1>${FMT[mode].name}: ${esc(w.name)}</h1><p>${list.length} topic${list.length === 1 ? "" : "s"}</p></div><button class="btn" data-go="study">Change selection</button></div>`;
  if (mode === "notes") {
    P.innerHTML = head + list.map(t => `<section class="panel section reader" style="--wc:${w.color}"><div class="shead"><h2>${esc(t.t)}</h2><button class="link" data-go="${t.id}">Open topic</button></div>
      ${t.hook ? `<p class="hk-inline">${fmt(t.hook)}</p>` : ""}<ol class="points">${t.pts.map(p => `<li><span class="pt">${fmt(p)}</span></li>`).join("")}</ol>
      ${t.code ? `<section class="codewrap" style="margin-top:12px"><pre><code>${hl(t.code)}</code></pre></section>` : ""}
      ${t.traps.length ? `<div class="tr-inline">${t.traps.map(x => "⚠ " + fmt(x)).join("<br>")}</div>` : ""}</section>`).join("");
  } else if (mode === "cheat") {
    P.innerHTML = head + `<div class="row noprint" style="margin-bottom:14px"><button class="btn" onclick="window.print()">${icon("print")}Print</button></div><div class="sheet">${list.map(cheatCard).join("")}</div>`;
  } else {
    P.innerHTML = head + `<div class="sess" id="sess"></div>`;
    const el = $("#sess");
    if (mode === "revision") cardSession(el, shuffle(list.flatMap(t => t.cards.map((c, i) => cardItem(t, i)))), {showTopic:true, after:`<button class="btn primary" data-go="study">Study modes</button>`});
    else if (mode === "interview") interviewSession(el, list.flatMap(t => t.iq.map(q => ({q:q[0], a:q[1], topic:t.t, color:w.color, tid:t.id}))), {max:10, again});
    else if (mode === "quiz") quizSession(el, shuffle(list.flatMap(t => t.quiz.map(q => prepQ(t, q)))).slice(0, 15), {again});
    else if (mode === "practical") arenaSession(el, shuffle(list.flatMap(t => t.prac.map(c => Object.assign({topic:t.t, color:w.color}, c)))), {max:8, again});
  }
  window.scrollTo(0, 0);
}

/* ================= add / edit skill ================= */
let wiz = null;
function newWiz(){ return {step:1, editId:null, name:"", icon:"🧠", color:skillColors[0], level:"Beginner", goal:"", topicsText:"", formats:["notes", "cheat", "revision", "interview", "quiz", "practical"], busy:false, error:"", ctl:null}; }
function openEdit(id){
  const sk = LIB.skills.find(x => x.id === id); if (!sk) return;
  wiz = {step:1, editId:id, name:sk.name, icon:sk.icon, color:sk.color, level:sk.level || "Beginner", goal:sk.goal || "", topicsText:sk.topics.map(t => t.t).join("\n"), formats:sk.formats.slice(), busy:false, error:"", ctl:null};
  go("editskill");
}
function renderWizard(P){
  if (!wiz || (route === "newskill" && wiz.editId)) wiz = newWiz();
  const editing = !!wiz.editId;
  const topics = wiz.topicsText.split("\n").map(x => x.trim()).filter(Boolean);
  const steps = ["Course", "Topics", "Sections"];
  P.innerHTML = `${crumbs([`<span>${editing ? "Edit course" : "Add a course"}</span>`])}
  <div class="phead"><div><h1>${editing ? "Edit " + esc(wiz.name) : "Add a course"}</h1><p>${editing ? "Change the details, add or remove topics, or choose different formats." : "Learning something new? Note down its topics and choose how you want to study it. Then write the notes topic by topic."}</p></div></div>
  <div class="stepper">${steps.map((s, k) => `<button class="${wiz.step === k + 1 ? "on" : wiz.step > k + 1 ? "done" : ""}" data-step="${k + 1}"><span>${k + 1}</span>${s}</button>`).join("")}</div>
  <section class="panel pad wiz">
  ${wiz.step === 1 ? `
    <label class="lbl" for="wname">Course name</label><input class="input" id="wname" placeholder="e.g. SQL, Docker, React, Statistics" value="${esc(wiz.name)}">
    <label class="lbl" style="margin-top:16px">Icon</label><div class="chips" style="margin:0 0 4px">${skillIcons.map(ic => `<button class="chip iconchip ${wiz.icon === ic ? "on" : ""}" data-icon="${ic}">${ic}</button>`).join("")}</div>
    <label class="lbl" style="margin-top:12px">Color</label><div class="swatches">${skillColors.map(c => `<button class="sw ${wiz.color === c ? "on" : ""}" style="--c:${c}" data-color="${c}" aria-label="Color ${c}"></button>`).join("")}</div>
    <label class="lbl" style="margin-top:16px">Your level</label><div class="seg">${["Beginner", "Intermediate", "Advanced"].map(l => `<button class="${wiz.level === l ? "on" : ""}" data-level="${l}">${l}</button>`).join("")}</div>
    <label class="lbl" for="wgoal" style="margin-top:16px">Why are you learning it? (optional)</label><input class="input" id="wgoal" placeholder="e.g. Data analyst interviews, building a side project" value="${esc(wiz.goal)}">
    <div class="row" style="margin-top:20px;justify-content:flex-end"><button class="btn primary" id="wnext">Next: topics</button></div>`
  : wiz.step === 2 ? `
    <div class="row" style="justify-content:space-between;align-items:flex-end"><div><label class="lbl" for="wtopics" style="margin:0">Topics, one per line</label><p class="muted small" style="margin:4px 0 0">Note down what you plan to learn, from basic to advanced. The order becomes your level path.</p></div>
      </div>
    <textarea class="input" id="wtopics" rows="12" style="margin-top:10px" placeholder="SELECT and filtering\nJoins\nGroup by and aggregates\nWindow functions">${esc(wiz.topicsText)}</textarea>
    <p class="muted small">${topics.length} topic${topics.length === 1 ? "" : "s"}</p>
    ${wiz.error ? `<p style="color:var(--bad)">${esc(wiz.error)}</p>` : ""}
    <div class="row" style="margin-top:16px;justify-content:space-between"><button class="btn" id="wback">Back</button><button class="btn primary" id="wnext" ${topics.length ? "" : "disabled"}>Next: sections</button></div>`
  : `
    <label class="lbl">How do you want to study ${esc(wiz.name || "it")}?</label><p class="muted small" style="margin:0 0 10px">These sections appear for every topic. You can change them later.</p>
    ${fmtPicker(wiz.formats, "data-wf")}
    <div class="summary"><b>${esc(wiz.icon)} ${esc(wiz.name)}</b><span class="muted small">${topics.length} topics, ${wiz.formats.map(f => FMT[f].name.toLowerCase()).join(", ") || "no formats yet"}</span></div>
    <div class="row" style="margin-top:16px;justify-content:space-between">
      <span class="row">${editing ? `<button class="btn danger" id="wdel">${icon("trash")}Delete course</button>` : ""}<button class="btn" id="wback">Back</button></span>
      <span class="row"><button class="btn primary" id="wcreate" ${wiz.formats.length ? "" : "disabled"}>${editing ? "Save changes" : "Create course"}</button></span></div>`}
  </section>`;
  const keep = () => { const n = $("#wname"); if (n) wiz.name = n.value; const g = $("#wgoal"); if (g) wiz.goal = g.value; const t = $("#wtopics"); if (t) wiz.topicsText = t.value; };
  P.querySelectorAll("input,textarea").forEach(x => x.oninput = keep);
  P.querySelectorAll("[data-step]").forEach(b => b.onclick = () => { keep(); const s = +b.dataset.step; if (s > 1 && !wiz.name.trim()) { toast("Name the course first"); return; } wiz.step = s; renderWizard(P); });
  P.querySelectorAll("[data-icon]").forEach(b => b.onclick = () => { keep(); wiz.icon = b.dataset.icon; renderWizard(P); });
  P.querySelectorAll("[data-color]").forEach(b => b.onclick = () => { keep(); wiz.color = b.dataset.color; renderWizard(P); });
  P.querySelectorAll("[data-level]").forEach(b => b.onclick = () => { keep(); wiz.level = b.dataset.level; renderWizard(P); });
  P.querySelectorAll("[data-wf]").forEach(c => c.onchange = () => { const id = c.dataset.wf; wiz.formats = c.checked ? wiz.formats.concat(id) : wiz.formats.filter(x => x !== id); wiz.formats = ALL_FMTS.filter(f => wiz.formats.includes(f)); renderWizard(P); });
  if ($("#wnext")) $("#wnext").onclick = () => { keep(); if (wiz.step === 1 && !wiz.name.trim()) { wiz.error = ""; toast("Name the course first"); $("#wname").focus(); return; } wiz.step++; wiz.error = ""; renderWizard(P); };
  if ($("#wback")) $("#wback").onclick = () => { keep(); wiz.step--; renderWizard(P); };
  if ($("#wcreate")) $("#wcreate").onclick = () => commitWizard(false);
  if ($("#wdel")) $("#wdel").onclick = async () => {
    const sk = LIB.skills.find(x => x.id === wiz.editId); if (!sk) return;
    if (!(await confirmBox("Delete " + esc(sk.name) + "?", `All ${sk.topics.length} topics, their notes and your progress on them will be removed. This can’t be undone.`, "Delete course", true))) return;
    const w = WORLDS.find(x => x.id === sk.id);
    if (w) w.topics.forEach(t => { t.cards.forEach((c, i) => delete S.cards[cardKey(t, i)]); delete S.topics[t.id]; });
    sk.topics.forEach(t => dropTopic(t.id));
    LIB.skills = LIB.skills.filter(x => x.id !== sk.id);
    saveLib(); save(); reindex(); wiz = null; go("library");
  };
}
function commitWizard(genAll){
  const titles = wiz.topicsText.split("\n").map(x => x.trim()).filter(Boolean);
  if (!wiz.name.trim() || !titles.length || !wiz.formats.length) return;
  let sk;
  if (wiz.editId) {
    sk = LIB.skills.find(x => x.id === wiz.editId);
    const keepList = [];
    titles.forEach(title => { const ex = sk.topics.find(t => t.t.toLowerCase() === title.toLowerCase() || (TC[t.id] && TC[t.id].t.toLowerCase() === title.toLowerCase())); keepList.push(ex || {id:sk.id + "-" + Math.random().toString(36).slice(2, 8), t:title}); });
    sk.topics.filter(t => !keepList.includes(t)).forEach(t => { dropTopic(t.id); delete S.topics[t.id]; });
    Object.assign(sk, {name:wiz.name.trim(), icon:wiz.icon, color:wiz.color, level:wiz.level, goal:wiz.goal.trim(), formats:wiz.formats.slice(), topics:keepList});
  } else {
    const id = "s" + Date.now().toString(36);
    sk = {id, name:wiz.name.trim(), icon:wiz.icon, color:wiz.color, level:wiz.level, goal:wiz.goal.trim(), formats:wiz.formats.slice(), created:tday(), topics:titles.map((t, k) => ({id:id + "-" + k, t}))};
    LIB.skills.push(sk);
  }
  saveLib(); save(); reindex();
  const editing = !!wiz.editId;
  wiz = null;
  toast(editing ? "Course updated" : "Course added: " + sk.name, !editing);
  checkBadges();
  go(sk.id);
}

/* ================= global events ================= */
document.addEventListener("click", e => {
  const mg = e.target.closest("[data-modego]");
  if (mg) { const [m, c] = mg.dataset.modego.split("|"); S.modeCourse = Object.assign({}, S.modeCourse, {[m]:c}); save(); go(m); return; }
  const ed = e.target.closest("[data-edit]");
  if (ed) { openEdit(ed.dataset.edit); return; }
  const a = e.target.closest("[data-go]");
  if (a) { e.preventDefault(); go(a.dataset.go); return; }
  const gt = e.target.closest("[data-go-tab]");
  if (gt) { const [id, tab] = gt.dataset.goTab.split("|"); go(id, {tab}); return; }
  const tb = e.target.closest("[data-tab]");
  if (tb && BYID[route]) { topicTab = tb.dataset.tab; renderPage(); return; }
  const bs = e.target.closest("[data-boss]");
  if (bs && !bs.disabled) { const w = WORLDS.find(x => x.id === bs.dataset.boss); if (w) startBoss(w); return; }
  const cs = e.target.closest("[data-cs]");
  if (cs) { csWorld = cs.dataset.cs; go("cheatsheets"); return; }
  const md = e.target.closest("[data-mode]");
  if (md) { go(md.dataset.mode); return; }
  const sd = e.target.closest("[data-study]");
  if (sd) { study.world = sd.dataset.study; if (!study.mode) study.mode = "quiz"; go("study"); }
});
document.addEventListener("keydown", e => {
  if (!$("#overlay").hidden) { if (e.key === "Escape") { $("#overlay").hidden = true; $("#overlay").innerHTML = ""; } return; }
  const tag = e.target.tagName;
  if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || e.altKey || e.ctrlKey || e.metaKey) return;
  if (e.key === "/" && $("#q")) { e.preventDefault(); $("#q").focus(); return; }
  if (keyHandler) keyHandler(e);
});

/* ================= write or edit notes yourself ================= */
function renderEditor(t){
  const el = $("#tbody"), c = TC[t.id] || {};
  const lines = a => (a || []).join("\n");
  const pairs = a => (a || []).map(x => x[0] + " | " + x[1]).join("\n");
  const quizTxt = (c.quiz || []).map(q => [q[0], q[1][q[2]]].concat(q[1].filter((_, k) => k !== q[2])).join(" | ")).join("\n");
  el.innerHTML = `<section class="panel pad editor" style="margin-top:18px">
    <div class="shead"><h2>${c.pts ? "Edit content" : "Write the notes yourself"}</h2><span class="muted small">Separate question and answer with a <code>|</code></span></div>
    <div class="grid g2" style="gap:12px"><div><label class="lbl" for="e_t">Title</label><input class="input" id="e_t" value="${esc(c.t || t.t)}"></div>
      <div><label class="lbl" for="e_h">Brain hook (one memorable line)</label><input class="input" id="e_h" value="${esc(c.hook || "")}"></div></div>
    <label class="lbl" for="e_s" style="margin-top:12px">Summary</label><textarea class="input" id="e_s" rows="2">${esc(c.sum || "")}</textarea>
    <label class="lbl" for="e_p" style="margin-top:12px">Key points, one per line</label><textarea class="input" id="e_p" rows="6" placeholder="Use \`backticks\` for code">${esc(lines(c.pts))}</textarea>
    <label class="lbl" for="e_c" style="margin-top:12px">Code example</label><textarea class="input mono" id="e_c" rows="6">${esc(c.code || "")}</textarea>
    <label class="lbl" for="e_tr" style="margin-top:12px">Interview traps, one per line</label><textarea class="input" id="e_tr" rows="3">${esc(lines(c.traps))}</textarea>
    <label class="lbl" for="e_f" style="margin-top:12px">Flashcards: question | answer</label><textarea class="input" id="e_f" rows="4" placeholder="What does a JOIN do? | Combines rows from two tables on a key">${esc(pairs(c.cards))}</textarea>
    <label class="lbl" for="e_i" style="margin-top:12px">Interview questions: question | model answer</label><textarea class="input" id="e_i" rows="4">${esc(pairs(c.iq))}</textarea>
    <label class="lbl" for="e_q" style="margin-top:12px">Quiz: question | correct answer | wrong | wrong | wrong</label><textarea class="input" id="e_q" rows="4" placeholder="Which join keeps all left rows? | LEFT JOIN | INNER JOIN | RIGHT JOIN | CROSS JOIN">${esc(quizTxt)}</textarea>
    <p class="formerr" id="e_err" hidden></p>
    <div class="row" style="margin-top:16px;justify-content:flex-end"><button class="btn" id="e_cancel">Cancel</button><button class="btn primary" id="e_save">Save notes</button></div>
  </section>`;
  $("#e_cancel").onclick = () => { editingTopic = null; renderPage(); };
  $("#e_save").onclick = () => {
    const v = id => $(id).value.trim();
    const ls = id => v(id).split("\n").map(x => x.trim()).filter(Boolean);
    const pr = id => ls(id).map(x => x.split("|").map(y => y.trim())).filter(x => x.length >= 2 && x[0] && x[1]).map(x => [x[0], x.slice(1).join(" | ")]);
    const quiz = ls("#e_q").map(x => x.split("|").map(y => y.trim()).filter(Boolean)).filter(x => x.length >= 3).map(x => [x[0], x.slice(1, 5), 0, "The correct answer is: " + x[1]]);
    const obj = {t:v("#e_t") || t.t, hook:v("#e_h"), sum:v("#e_s"), pts:ls("#e_p"), code:$("#e_c").value.replace(/\s+$/, ""), traps:ls("#e_tr"), cards:pr("#e_f"), iq:pr("#e_i"), quiz};
    if (!obj.pts.length && !obj.cards.length && !obj.quiz.length && !obj.iq.length) { const e = $("#e_err"); e.hidden = false; e.textContent = "Add at least some key points, flashcards, interview questions or quiz questions."; return; }
    TC[t.id] = Object.assign({}, c, obj, {id:t.id, prac:c.prac || [], created:c.created || tday()});
    const st = t.world.skill.topics.find(x => x.id === t.id); if (st) st.t = obj.t;
    saveTopic(t.id); saveLib(); reindex(); editingTopic = null;
    toast("Notes saved"); renderPage();
  };
}

function fmtPicker(sel, attr){
  return `<div class="fmtpick">${FORMATS.map(f => `<label class="fp ${sel.includes(f.id) ? "on" : ""}"><input type="checkbox" ${attr}="${f.id}" ${sel.includes(f.id) ? "checked" : ""}>${icon(f.icon)}<span><b>${f.name}</b><small>${f.desc}</small></span></label>`).join("")}</div>`;
}
