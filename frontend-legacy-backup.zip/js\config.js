// Where the Recall backend (FastAPI) runs. Change this when you deploy.
window.RECALL_CONFIG = {
  API_URL: "http://localhost:8000"
};
