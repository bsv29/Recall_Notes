/* ================= start ================= */
(async () => {
  $("#root").innerHTML = `<div class="boot"><span class="spin"></span><span class="muted">Loading Recall…</span></div>`;
  const ok = await restoreSession();
  const startHash = location.hash.slice(1);
  if (validRoute(startHash)) route = startHash;
  else if (ok && S.onboarded && S.lastRoute && validRoute(S.lastRoute) && S.lastRoute !== "editskill") route = S.lastRoute;
  render();
  if (ok && syncState === "offline") toast("Offline: changes will sync when the server is reachable");
})();
